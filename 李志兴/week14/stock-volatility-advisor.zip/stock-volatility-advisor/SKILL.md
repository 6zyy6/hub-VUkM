---
name: stock-volatility-advisor
description: 根据股票代码或历史价格 CSV 生成股票近一段时间的日波动、周波动图，并给出简单买卖时间建议。适用于类似“分析 AAPL 近 6 个月波动，画出日波动和周波动，并给出简单买卖时间建议”的请求。
---

# 股票波动分析助手
## 概览

使用这个 Skill 生成一份简洁、可直接交付给用户的股票波动分析结果。它会：

- 画出同一时期的日波动和周波动
- 给出一个简单的买入候选日和卖出候选日
- 生成可引用的 PNG 图表和 Markdown 摘要

这个 Skill 适用于：

- 分析 AAPL 近 6 个月波动，画出日波动和周波动，并给出简单买卖时间建议
- 看 TSLA 最近一年波动情况，并给出简单的买卖时间提示
- 用一份 CSV 分析 0700.HK 的日波动和周波动

不要把结果表述成正式投资建议。

## 输入方式

优先支持两种输入：

1. 直接给股票代码和时间范围
   - 例如：`AAPL`、`TSLA`、`0700.HK`、`600519.SS`
   - 时间范围映射为：`1mo`、`3mo`、`6mo`、`1y`、`2y`、`5y`、`ytd`
   - 用户说“近 6 个月”时，默认映射成 `6mo`

2. 提供历史价格 CSV
   - 日期列可识别：`Date`、`Datetime`、`Time`、`Timestamp`、`日期`、`时间`
   - 收盘价列可识别：`Close`、`Adj Close`、`Adjusted Close`、`Price`、`收盘`、`收盘价`
   - 如果列名不标准，运行脚本时用 `--date-col` 和 `--price-col` 指定

## 执行环境约定

运行这个 Skill 的 Python 脚本时，优先使用 conda 环境 `py312`。

推荐命令：

```bash
conda run -n py312 python scripts/stock_volatility_visualizer.py --ticker AAPL --period 6mo --output-dir outputs
```

如果在线获取失败，脚本会自动尝试多个数据源；只有多个数据源都失败时，才提示改用 CSV。

如果 `py312` 不存在、`conda` 不可用或依赖未安装，应先安装：

```bash
conda run -n py312 python -m pip install -r scripts/requirements.txt
```

## 工作流程

1. 从用户问题里识别：
   - 股票代码，例如 `AAPL`
   - 时间范围，例如“近 6 个月”映射成 `6mo`

2. 默认优先走股票代码模式：

   ```bash
   conda run -n py312 python scripts/stock_volatility_visualizer.py --ticker AAPL --period 6mo --output-dir outputs
   ```

3. 如果用户提供的是 CSV，则运行：

   ```bash
   conda run -n py312 python scripts/stock_volatility_visualizer.py prices.csv --ticker AAPL --output-dir outputs
   ```

4. 返回生成的图表和摘要，并用中文给出简洁解释：
   - 区间价格表现如何
   - 买入候选日和卖出候选日分别是哪天
   - 为什么这些日期被挑出来

5. 明确提醒：
   - 这是启发式分析
   - 不构成投资建议
   - 未考虑估值、财报、新闻、交易成本、税务和个人风险承受能力

## 参数映射建议

- 近 1 个月 / 最近 1 个月 -> `1mo`
- 近 3 个月 / 最近一季度 -> `3mo`
- 近 6 个月 / 最近半年 -> `6mo`
- 近 1 年 / 最近一年 -> `1y`
- 近 2 年 -> `2y`
- 近 5 年 -> `5y`
- 今年以来 -> `ytd`

如果用户没有明确给时间范围，默认用 `6mo`。

## 脚本行为

`scripts/stock_volatility_visualizer.py` 会：

1. 优先通过在线行情获取价格数据
   - 先尝试 `yfinance`
   - 如果失败，再自动回退到 `Pocket Portfolio`
   - 如果都失败，再提示上传 CSV

2. 计算：
   - 日收益率：`close.pct_change()`
   - 日波动：日收益率绝对值
   - 周波动：按周计算日收益率标准差，再乘 `sqrt(5)`
   - 5 日动量：`close.pct_change(5)`

3. 使用简单启发式规则：
   - 买入候选：周波动较低，同时 5 日动量改善
   - 卖出候选：周波动较高，同时 5 日动量走弱

4. 输出：
   - `<ticker>_<period>_daily_weekly_volatility.png`
   - `<ticker>_<period>_summary.md`

## 示例

查看 `references/example_usage.md`。

## 回复风格

回复应简洁、实用、使用中文：

- 如果图表文件可用，提供图表链接
- 明确买入候选日和卖出候选日
- 简短解释入选原因
- 提醒这只是启发式分析，不是投资建议
