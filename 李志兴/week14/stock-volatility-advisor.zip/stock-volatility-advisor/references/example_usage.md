# 示例用法

## 场景 1：用户直接提问

用户说：

> 分析 AAPL 近 6 个月波动，画出日波动和周波动，并给出简单买卖时间建议。

推荐执行：

```bash
conda run -n py312 python scripts/stock_volatility_visualizer.py --ticker AAPL --period 6mo --output-dir outputs
```

脚本会创建：

- `outputs/AAPL_6mo_daily_weekly_volatility.png`
- `outputs/AAPL_6mo_summary.md`

## 场景 2：用户提供 CSV

假设 `prices.csv` 包含：

```csv
Date,Close
2026-01-02,100.12
2026-01-05,101.30
...
```

运行：

```bash
conda run -n py312 python scripts/stock_volatility_visualizer.py prices.csv --ticker AAPL --output-dir outputs
```

## 输出解释

- 日波动是每日百分比收益率的绝对值
- 周波动是每周日收益率标准差乘以 `sqrt(5)`，用于保留周级别的波动尺度
- 买入候选偏向“较低周波动 + 5 日动量改善”的时点
- 卖出候选偏向“较高周波动 + 5 日动量走弱”的时点

## 回复示例

- 已根据 AAPL 近 6 个月数据生成日波动和周波动图。
- 买入候选日出现在周波动较低且短期动量改善的时点。
- 卖出候选日出现在周波动较高且短期动量走弱的时点。
- 这只是启发式分析结果，不构成投资建议。
