#!/usr/bin/env python3
"""Generate daily/weekly volatility charts and simple timing hints for a stock."""

from __future__ import annotations

import argparse
import csv
import math
import re
from io import StringIO
from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import pandas as pd
import requests
from matplotlib import font_manager


DATE_CANDIDATES = ["date", "datetime", "time", "timestamp", "日期", "时间", "交易日期"]
PRICE_CANDIDATES = [
    "adj close",
    "adjusted close",
    "close",
    "last",
    "price",
    "收盘",
    "收盘价",
    "调整收盘价",
    "价格",
]
PERIOD_CHOICES = ["1mo", "3mo", "6mo", "1y", "2y", "5y", "ytd"]
POCKET_PORTFOLIO_RANGE_MAP = {
    "1mo": "1mo",
    "3mo": "3mo",
    "6mo": "6mo",
    "1y": "1y",
    "2y": "2y",
    "5y": "5y",
    "ytd": "ytd",
}
DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 Codex stock-volatility-advisor"}


def _setup_chinese_font() -> None:
    preferred_fonts = [
        "Noto Sans CJK SC",
        "Noto Sans CJK JP",
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "WenQuanYi Zen Hei",
        "Arial Unicode MS",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for font_name in preferred_fonts:
        if font_name in available:
            plt.rcParams["font.sans-serif"] = [font_name]
            break
    plt.rcParams["axes.unicode_minus"] = False


def _slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._\-\u4e00-\u9fff]+", "_", value.strip())
    return value.strip("_") or "stock"


def _find_column(columns: list[str], candidates: list[str]) -> Optional[str]:
    normalized = {c.lower().strip(): c for c in columns}
    for candidate in candidates:
        if candidate in normalized:
            return normalized[candidate]
    for column in columns:
        normalized_column = column.lower().strip()
        if any(candidate in normalized_column for candidate in candidates):
            return column
    return None


def _ensure_min_rows(dataframe: pd.DataFrame) -> pd.DataFrame:
    if len(dataframe) < 10:
        raise ValueError("至少需要 10 行有效价格数据才能计算波动。")
    return dataframe


def _load_prices_from_csv(
    csv_path: Path,
    date_col: Optional[str],
    price_col: Optional[str],
) -> pd.DataFrame:
    if not csv_path.exists():
        raise FileNotFoundError(f"找不到 CSV 文件: {csv_path}")

    dataframe = pd.read_csv(csv_path)
    if dataframe.empty:
        raise ValueError("CSV 文件为空。")

    if date_col is None:
        date_col = _find_column(list(dataframe.columns), DATE_CANDIDATES)
    if date_col is None or date_col not in dataframe.columns:
        raise ValueError("找不到日期列，请用 --date-col 指定，例如 Date 或 日期。")

    if price_col is None:
        price_col = _find_column(list(dataframe.columns), PRICE_CANDIDATES)
    if price_col is None or price_col not in dataframe.columns:
        numeric_columns = [c for c in dataframe.columns if pd.api.types.is_numeric_dtype(dataframe[c])]
        if numeric_columns:
            price_col = numeric_columns[-1]
        else:
            raise ValueError("找不到价格列，请用 --price-col 指定，例如 Close 或 收盘价。")

    output = dataframe[[date_col, price_col]].copy()
    output.columns = ["date", "close"]
    output["date"] = pd.to_datetime(output["date"], errors="coerce")
    output["close"] = pd.to_numeric(output["close"], errors="coerce")
    output = output.dropna(subset=["date", "close"]).sort_values("date")
    output = output.drop_duplicates(subset=["date"], keep="last")
    return _ensure_min_rows(output.set_index("date"))


def _normalize_online_prices(dataframe: pd.DataFrame, ticker: str) -> pd.DataFrame:
    if dataframe is None or dataframe.empty:
        raise ValueError(f"未获取到 {ticker} 的历史行情。")

    if isinstance(dataframe.columns, pd.MultiIndex):
        try:
            dataframe = dataframe.xs(ticker, axis=1, level=-1)
        except Exception:
            dataframe.columns = [c[0] if isinstance(c, tuple) else c for c in dataframe.columns]

    price_col = None
    for candidate in ["Adj Close", "Close"]:
        if candidate in dataframe.columns and dataframe[candidate].notna().any():
            price_col = candidate
            break

    if price_col is None:
        raise ValueError("在线行情结果里找不到 Close 或 Adj Close 列。")

    output = dataframe[[price_col]].copy().rename(columns={price_col: "close"})
    output.index = pd.to_datetime(output.index, errors="coerce")
    output = output.dropna(subset=["close"]).sort_index()
    output.index.name = "date"
    return _ensure_min_rows(output)


def _fetch_with_yfinance(ticker: str, period: str) -> pd.DataFrame:
    try:
        import yfinance as yf
    except ImportError as exc:
        raise RuntimeError("缺少依赖 yfinance。") from exc

    try:
        dataframe = yf.download(ticker, period=period, auto_adjust=False, progress=False)
    except Exception as exc:
        raise RuntimeError(f"yfinance 下载失败: {exc}") from exc

    return _normalize_online_prices(dataframe, ticker)


def _fetch_with_pocket_portfolio(ticker: str, period: str) -> pd.DataFrame:
    mapped_period = POCKET_PORTFOLIO_RANGE_MAP.get(period)
    if not mapped_period:
        raise ValueError(f"Pocket Portfolio 不支持 period={period}")

    url = f"https://www.pocketportfolio.app/api/tickers/{ticker}/json?range={mapped_period}"
    response = requests.get(url, headers=DEFAULT_HEADERS, timeout=30)
    response.raise_for_status()
    payload = response.json()
    rows = payload.get("data") or []
    if not rows:
        raise ValueError(f"Pocket Portfolio 未返回 {ticker} 的历史数据。")

    buffer = StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["date", "close"])
    for row in rows:
        writer.writerow([row.get("date"), row.get("close")])
    buffer.seek(0)

    dataframe = pd.read_csv(buffer)
    dataframe["date"] = pd.to_datetime(dataframe["date"], errors="coerce")
    dataframe["close"] = pd.to_numeric(dataframe["close"], errors="coerce")
    dataframe = dataframe.dropna(subset=["date", "close"]).sort_values("date")
    return _ensure_min_rows(dataframe.set_index("date"))


def _load_prices_from_ticker(ticker: str, period: str) -> tuple[pd.DataFrame, str]:
    if period not in PERIOD_CHOICES:
        raise ValueError(f"不支持的 period: {period}。可选值: {', '.join(PERIOD_CHOICES)}")

    errors: list[str] = []
    for source_name, loader in (
        ("yfinance", _fetch_with_yfinance),
        ("Pocket Portfolio", _fetch_with_pocket_portfolio),
    ):
        try:
            return loader(ticker, period), source_name
        except Exception as exc:
            errors.append(f"{source_name}: {exc}")

    raise RuntimeError(
        f"在线获取 {ticker} {period} 数据失败。已尝试的数据源: {' | '.join(errors)}。"
        "请改为上传包含 Date 和 Close 列的 CSV。"
    )


def _compute_signals(prices: pd.DataFrame) -> pd.DataFrame:
    signals = prices.copy()
    signals["daily_return"] = signals["close"].pct_change()
    signals["daily_volatility"] = signals["daily_return"].abs()
    signals["momentum_5d"] = signals["close"].pct_change(5)

    weekly = signals["daily_return"].resample("W-FRI").std() * math.sqrt(5)
    weekly = weekly.rename("weekly_volatility").dropna()
    if weekly.empty:
        raise ValueError("数据不足，无法计算周波动。")

    signals = signals.join(weekly.reindex(signals.index, method="ffill"))
    signals = signals.dropna(subset=["daily_volatility", "weekly_volatility", "momentum_5d"])
    if signals.empty:
        raise ValueError("波动计算后没有足够的有效数据。")
    return signals


def _pick_timing(signals: pd.DataFrame) -> tuple[pd.Timestamp, pd.Timestamp, pd.Series, pd.Series]:
    volatility = signals["weekly_volatility"]
    volatility_range = max(volatility.max() - volatility.min(), 1e-12)
    momentum = signals["momentum_5d"].fillna(0)
    momentum_range = max(momentum.max() - momentum.min(), 1e-12)

    low_vol_score = 1 - ((volatility - volatility.min()) / volatility_range)
    high_vol_score = (volatility - volatility.min()) / volatility_range
    positive_momentum_score = (momentum - momentum.min()) / momentum_range
    negative_momentum_score = 1 - positive_momentum_score

    buy_score = 0.65 * low_vol_score + 0.35 * positive_momentum_score
    sell_score = 0.65 * high_vol_score + 0.35 * negative_momentum_score

    buy_date = buy_score.idxmax()
    sell_date = sell_score.idxmax()
    return buy_date, sell_date, buy_score, sell_score


def _pct(value: float) -> str:
    return f"{value * 100:.2f}%"


def _plot(
    signals: pd.DataFrame,
    buy_date: pd.Timestamp,
    sell_date: pd.Timestamp,
    ticker: str,
    period_label: str,
    output_png: Path,
) -> None:
    _setup_chinese_font()
    figure, axis = plt.subplots(figsize=(12, 6))
    axis.plot(
        signals.index,
        signals["daily_volatility"] * 100,
        label="日波动: 日收益率绝对值 (%)",
        linewidth=1.0,
    )
    axis.plot(
        signals.index,
        signals["weekly_volatility"] * 100,
        label="周波动: 周标准差 × sqrt(5) (%)",
        linewidth=2.0,
    )
    axis.axvline(buy_date, linestyle="--", linewidth=1.2, label=f"买入候选: {buy_date.date()}")
    axis.axvline(sell_date, linestyle=":", linewidth=1.5, label=f"卖出候选: {sell_date.date()}")
    axis.set_title(f"{ticker} {period_label} 日波动与周波动")
    axis.set_xlabel("日期")
    axis.set_ylabel("波动率 (%)")
    axis.grid(True, alpha=0.3)
    axis.legend(loc="best")
    figure.autofmt_xdate()
    figure.tight_layout()
    figure.savefig(output_png, dpi=160)
    plt.close(figure)


def _write_summary(
    signals: pd.DataFrame,
    buy_date: pd.Timestamp,
    sell_date: pd.Timestamp,
    buy_score: pd.Series,
    sell_score: pd.Series,
    ticker: str,
    period_label: str,
    source_desc: str,
    output_md: Path,
    output_png: Path,
) -> None:
    latest = signals.iloc[-1]
    buy_row = signals.loc[buy_date]
    sell_row = signals.loc[sell_date]

    text = f"""# {ticker} 波动摘要
图表文件：`{output_png.name}`
数据来源：{source_desc}
分析区间：{period_label}

## 简单时点提示
- 买入候选日：**{buy_date.date()}**
  - 收盘价：{buy_row['close']:.4f}
  - 日波动：{_pct(buy_row['daily_volatility'])}
  - 周波动：{_pct(buy_row['weekly_volatility'])}
  - 5 日动量：{_pct(buy_row['momentum_5d'])}
  - 综合分数：{buy_score.loc[buy_date]:.3f}

- 卖出候选日：**{sell_date.date()}**
  - 收盘价：{sell_row['close']:.4f}
  - 日波动：{_pct(sell_row['daily_volatility'])}
  - 周波动：{_pct(sell_row['weekly_volatility'])}
  - 5 日动量：{_pct(sell_row['momentum_5d'])}
  - 综合分数：{sell_score.loc[sell_date]:.3f}

## 最新一日
- 日期：**{signals.index[-1].date()}**
- 收盘价：{latest['close']:.4f}
- 日波动：{_pct(latest['daily_volatility'])}
- 周波动：{_pct(latest['weekly_volatility'])}
- 5 日动量：{_pct(latest['momentum_5d'])}

## 规则说明
这是一套教学型启发式规则：
- 买入候选偏向“较低周波动 + 改善中的 5 日动量”
- 卖出候选偏向“较高周波动 + 走弱中的 5 日动量”

这不是投资建议，也没有考虑估值、基本面、新闻、交易成本、税务、流动性或个人风险承受能力。
"""
    output_md.write_text(text, encoding="utf-8")


def run(args: argparse.Namespace) -> tuple[Path, Path]:
    source = args.source
    ticker = args.ticker
    period = args.period

    source_desc: str
    period_label = period

    if source:
        source_path = Path(source).expanduser()
        if source_path.exists() and source_path.is_file():
            output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else source_path.resolve().parent
            prices = _load_prices_from_csv(source_path.resolve(), args.date_col, args.price_col)
            ticker = _slug(ticker or source_path.stem)
            source_desc = f"CSV: {source_path.name}"
            period_label = f"{prices.index.min().date()} 至 {prices.index.max().date()}"
            suffix = "csv"
        else:
            ticker = source
            output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else Path.cwd()
            prices, online_source = _load_prices_from_ticker(ticker, period)
            ticker = _slug(ticker)
            source_desc = f"在线行情: {online_source}"
            period_label = f"{prices.index.min().date()} 至 {prices.index.max().date()}"
            suffix = _slug(period)
    else:
        if not ticker:
            raise ValueError("请提供股票代码，例如 --ticker AAPL，或提供一个 CSV 文件路径。")
        output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else Path.cwd()
        prices, online_source = _load_prices_from_ticker(ticker, period)
        ticker = _slug(ticker)
        source_desc = f"在线行情: {online_source}"
        period_label = f"{prices.index.min().date()} 至 {prices.index.max().date()}"
        suffix = _slug(period)

    output_dir.mkdir(parents=True, exist_ok=True)

    signals = _compute_signals(prices)
    buy_date, sell_date, buy_score, sell_score = _pick_timing(signals)

    png_path = output_dir / f"{ticker}_{suffix}_daily_weekly_volatility.png"
    md_path = output_dir / f"{ticker}_{suffix}_summary.md"
    _plot(signals, buy_date, sell_date, ticker, period_label, png_path)
    _write_summary(signals, buy_date, sell_date, buy_score, sell_score, ticker, period_label, source_desc, md_path, png_path)
    return png_path, md_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="绘制股票日波动与周波动，并生成简单买卖时间提示。")
    parser.add_argument(
        "source",
        nargs="?",
        help="可选输入: CSV 文件路径；如果传入的是非文件字符串，会视为股票代码。",
    )
    parser.add_argument("--ticker", help="股票代码或显示名称，例如 AAPL、TSLA、0700.HK")
    parser.add_argument(
        "--period",
        default="6mo",
        choices=PERIOD_CHOICES,
        help="在线获取行情时使用的时间范围，默认 6mo",
    )
    parser.add_argument("--date-col", help="CSV 日期列名，例如 Date 或 日期")
    parser.add_argument("--price-col", help="CSV 价格列名，例如 Close、Adj Close 或 收盘价")
    parser.add_argument("--output-dir", help="保存 PNG 和 Markdown 输出的目录")
    return parser.parse_args()


if __name__ == "__main__":
    png, md = run(parse_args())
    print(f"PNG: {png}")
    print(f"SUMMARY: {md}")
