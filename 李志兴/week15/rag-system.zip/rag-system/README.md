# 多模态 RAG 问答系统

本项目严格按 `项目方案.md` 第一版范围实现：单人本地使用、多知识库、单知识库问答、Docker Compose 本地部署、FastAPI + React + PostgreSQL + Milvus + Kafka + MinerU，并通过外部可配置 HTTP 服务接入 Qwen-VL、Embedding、Reranker。

## 快速开始

```bash
cp .env.example .env
cp config/app.yaml.example config/app.yaml
mkdir -p storage/originals storage/parsed storage/previews storage/temp

docker compose up -d --build
```

模型服务（Qwen-VL、Embedding、Reranker）不在主 `docker-compose.yml` 中启动，需要按 `docs/model-services.md` 单独部署，并在 `config/app.yaml` 或 `.env` 中配置服务地址与密钥。

## 目录结构

```text
rag-system/
  backend/
  workers/
  frontend/
  config/
  docs/
  scripts/
  tests/
  docker/
  storage/
  docker-compose.yml
  .env.example
  README.md
```

## 第一版重点约束

- 不实现登录认证、多用户、组织空间和跨知识库检索。
- 每次问答只能选择一个知识库。
- 检索必须按 `knowledge_base_id` 过滤。
- Milvus 使用单 Collection：`rag_document_chunks`。
- Prompt 正文放在 `config/prompts/`，业务代码不得硬编码 Prompt。
- API Key 不写入数据库，不输出到日志。
- 问答采用严格 RAG：依据不足时必须说明当前知识库中未找到足够依据。
