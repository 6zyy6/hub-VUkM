from fastapi import APIRouter

from app.api.v1.routes import chunks, config, files, health, knowledge_bases, qa, tasks

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(config.router, prefix="/config", tags=["config"])
api_router.include_router(knowledge_bases.router, prefix="/knowledge-bases", tags=["knowledge-bases"])
api_router.include_router(files.router, tags=["files"])
api_router.include_router(tasks.router, tags=["tasks"])
api_router.include_router(chunks.router, tags=["chunks"])
api_router.include_router(qa.router, tags=["qa"])
