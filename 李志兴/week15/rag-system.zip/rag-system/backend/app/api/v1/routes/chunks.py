from uuid import UUID

from fastapi import APIRouter, Depends
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.db.session import get_session
from app.repositories.files import FileRepository
from app.repositories.qa import QARepository
from app.schemas.files import ChunkRead
from app.utils.storage import safe_asset_path

router = APIRouter()


@router.get("/files/{file_id}/chunks", response_model=list[ChunkRead])
async def list_chunks(file_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileRepository(db).list_chunks(file_id)


@router.get("/chunks/{chunk_id}", response_model=ChunkRead)
async def get_chunk(chunk_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileRepository(db).get_chunk(chunk_id)


@router.get("/assets/{asset_id}")
async def get_asset(asset_id: UUID, db: AsyncSession = Depends(get_session)):
    asset = await FileRepository(db).get_asset(asset_id)
    path = safe_asset_path(asset.asset_path, get_settings().storage)
    return FileResponse(path)


@router.get("/references/{reference_id}/preview")
async def reference_preview(reference_id: UUID, db: AsyncSession = Depends(get_session)):
    repo = QARepository(db)
    ref = await repo.get_reference(reference_id)
    chunk = await FileRepository(db).get_chunk(ref.chunk_id)
    asset = await FileRepository(db).get_asset(ref.asset_id) if ref.asset_id else None
    return {
        "reference": {
            "id": str(ref.id),
            "page_number": ref.page_number,
            "bbox": ref.bbox,
            "quote_text": ref.quote_text,
            "metadata": ref.metadata_,
        },
        "chunk": {
            "id": str(chunk.id),
            "chunk_type": chunk.chunk_type,
            "content_text": chunk.content_text,
            "sheet_name": chunk.sheet_name,
            "row_range": chunk.row_range,
            "col_range": chunk.col_range,
            "table_id": chunk.table_id,
        },
        "asset": {
            "id": str(asset.id),
            "asset_type": asset.asset_type,
            "page_number": asset.page_number,
            "bbox": asset.bbox,
            "url": f"/api/v1/assets/{asset.id}",
        } if asset else None,
    }
