from fastapi import APIRouter

from app.core.config import get_settings
from app.services.dependency_health_service import DependencyHealthService

router = APIRouter()


@router.get("/public")
async def public_config() -> dict:
    return get_settings().public_config()


@router.post("/model-services/test")
async def test_model_services() -> dict:
    checks = await DependencyHealthService().check_dependencies()
    return {k: v for k, v in checks.items() if k in {"llm", "embedding", "reranker"}}
