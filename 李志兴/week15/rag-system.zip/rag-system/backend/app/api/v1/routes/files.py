from uuid import UUID

from fastapi import APIRouter, Depends, File, Response, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_session
from app.repositories.files import FileRepository
from app.schemas.files import FileRead, FileTaskRead
from app.services.file_service import FileService

router = APIRouter()


@router.post("/knowledge-bases/{knowledge_base_id}/files", response_model=list[FileRead], status_code=status.HTTP_201_CREATED)
async def upload_files(knowledge_base_id: UUID, files: list[UploadFile] = File(...), db: AsyncSession = Depends(get_session)):
    return await FileService(db).upload_files(knowledge_base_id, files)


@router.get("/knowledge-bases/{knowledge_base_id}/files", response_model=list[FileRead])
async def list_files(knowledge_base_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileService(db).list_by_kb(knowledge_base_id)


@router.get("/files/{file_id}", response_model=FileRead)
async def get_file(file_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileService(db).get(file_id)


@router.delete("/files/{file_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_file(file_id: UUID, db: AsyncSession = Depends(get_session)):
    await FileService(db).delete(file_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/files/{file_id}/retry", response_model=FileTaskRead)
async def retry_file(file_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileService(db).retry(file_id)


@router.get("/files/{file_id}/tasks", response_model=list[FileTaskRead])
async def list_file_tasks(file_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileRepository(db).list_tasks(file_id)
