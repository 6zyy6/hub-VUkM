from fastapi import APIRouter

from app.services.dependency_health_service import DependencyHealthService

router = APIRouter()


@router.get("/health/dependencies")
async def dependency_health() -> dict:
    return await DependencyHealthService().check_dependencies()
