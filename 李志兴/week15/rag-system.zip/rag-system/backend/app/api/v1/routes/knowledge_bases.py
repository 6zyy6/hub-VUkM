from uuid import UUID

from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_session
from app.schemas.common import KnowledgeBaseCreate, KnowledgeBaseRead, KnowledgeBaseUpdate
from app.services.knowledge_base_service import KnowledgeBaseService

router = APIRouter()


@router.post("", response_model=KnowledgeBaseRead, status_code=status.HTTP_201_CREATED)
async def create_kb(payload: KnowledgeBaseCreate, db: AsyncSession = Depends(get_session)):
    return await KnowledgeBaseService(db).create(payload.name, payload.description)


@router.get("", response_model=list[KnowledgeBaseRead])
async def list_kbs(db: AsyncSession = Depends(get_session)):
    return await KnowledgeBaseService(db).list()


@router.get("/{knowledge_base_id}", response_model=KnowledgeBaseRead)
async def get_kb(knowledge_base_id: UUID, db: AsyncSession = Depends(get_session)):
    return await KnowledgeBaseService(db).get(knowledge_base_id)


@router.patch("/{knowledge_base_id}", response_model=KnowledgeBaseRead)
async def update_kb(knowledge_base_id: UUID, payload: KnowledgeBaseUpdate, db: AsyncSession = Depends(get_session)):
    return await KnowledgeBaseService(db).update(knowledge_base_id, payload.name, payload.description)


@router.delete("/{knowledge_base_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_kb(knowledge_base_id: UUID, db: AsyncSession = Depends(get_session)):
    await KnowledgeBaseService(db).delete(knowledge_base_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
