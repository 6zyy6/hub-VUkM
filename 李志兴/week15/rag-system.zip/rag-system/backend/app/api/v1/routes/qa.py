from uuid import UUID

from fastapi import APIRouter, Depends, Response, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_session
from app.repositories.qa import QARepository
from app.schemas.qa import MessageRead, QuestionCreate, ReferenceRead, SessionCreate, SessionRead, SessionUpdate
from app.services.qa_service import QAService

router = APIRouter()


@router.post("/knowledge-bases/{knowledge_base_id}/sessions", response_model=SessionRead, status_code=status.HTTP_201_CREATED)
async def create_session(knowledge_base_id: UUID, payload: SessionCreate, db: AsyncSession = Depends(get_session)):
    return await QAService(db).create_session(knowledge_base_id, payload.title)


@router.get("/knowledge-bases/{knowledge_base_id}/sessions", response_model=list[SessionRead])
async def list_sessions(knowledge_base_id: UUID, db: AsyncSession = Depends(get_session)):
    return await QARepository(db).list_sessions(knowledge_base_id)


@router.get("/sessions/{session_id}", response_model=SessionRead)
async def get_session(session_id: UUID, db: AsyncSession = Depends(get_session)):
    return await QARepository(db).get_session(session_id)


@router.patch("/sessions/{session_id}", response_model=SessionRead)
async def update_session(session_id: UUID, payload: SessionUpdate, db: AsyncSession = Depends(get_session)):
    return await QAService(db).update_session(session_id, payload.title)


@router.delete("/sessions/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_session(session_id: UUID, db: AsyncSession = Depends(get_session)):
    await QAService(db).delete_session(session_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/sessions/{session_id}/messages", response_model=list[MessageRead])
async def list_messages(session_id: UUID, db: AsyncSession = Depends(get_session)):
    return await QARepository(db).list_messages(session_id)


@router.post("/sessions/{session_id}/messages/stream")
async def stream_message(session_id: UUID, payload: QuestionCreate, db: AsyncSession = Depends(get_session)):
    service = QAService(db)
    return StreamingResponse(service.stream_answer(session_id, payload.question), media_type="text/event-stream")


@router.get("/messages/{message_id}", response_model=MessageRead)
async def get_message(message_id: UUID, db: AsyncSession = Depends(get_session)):
    return await QARepository(db).get_message(message_id)


@router.get("/messages/{message_id}/references", response_model=list[ReferenceRead])
async def list_references(message_id: UUID, db: AsyncSession = Depends(get_session)):
    return await QARepository(db).list_references(message_id)
