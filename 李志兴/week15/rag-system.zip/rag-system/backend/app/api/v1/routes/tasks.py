from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_session
from app.repositories.files import FileRepository
from app.schemas.files import FileTaskRead

router = APIRouter()


@router.get("/tasks/{task_id}", response_model=FileTaskRead)
async def get_task(task_id: UUID, db: AsyncSession = Depends(get_session)):
    return await FileRepository(db).get_task(task_id)
