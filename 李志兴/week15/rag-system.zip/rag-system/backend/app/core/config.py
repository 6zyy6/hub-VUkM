import os
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, field_validator

_ENV_PATTERN = re.compile(r"\$\{([^}:]+)(?::-(.*?))?\}")


def _resolve_env(value: Any) -> Any:
    if isinstance(value, str):
        def repl(match: re.Match[str]) -> str:
            name, default = match.group(1), match.group(2)
            return os.getenv(name, default or "")
        return _ENV_PATTERN.sub(repl, value)
    if isinstance(value, dict):
        return {k: _resolve_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_env(v) for v in value]
    return value


class AppConfig(BaseModel):
    env: str = "local"
    api_prefix: str = "/api/v1"


class StorageConfig(BaseModel):
    root_dir: str = "storage"
    originals_dir: str = "storage/originals"
    parsed_dir: str = "storage/parsed"
    previews_dir: str = "storage/previews"
    temp_dir: str = "storage/temp"


class PostgresConfig(BaseModel):
    dsn: str

    @property
    def async_dsn(self) -> str:
        if self.dsn.startswith("postgresql+asyncpg://"):
            return self.dsn
        return self.dsn.replace("postgresql://", "postgresql+asyncpg://", 1)


class KafkaConfig(BaseModel):
    bootstrap_servers: str
    file_task_topic: str = "rag_file_task"
    file_task_failed_topic: str = "rag_file_task_failed"


class MinerUConfig(BaseModel):
    base_url: str
    timeout_seconds: int = 600


class HNSWConfig(BaseModel):
    M: int = 16
    efConstruction: int = 200
    ef: int = 64


class MilvusConfig(BaseModel):
    uri: str
    collection: str = "rag_document_chunks"
    metric_type: str = "COSINE"
    index_type: str = "HNSW"
    vector_dim: int = 1024
    hnsw: HNSWConfig = Field(default_factory=HNSWConfig)


class LLMConfig(BaseModel):
    provider: str = "qwen-vl-compatible"
    base_url: str
    model: str
    api_key: str = ""
    temperature: float = 0.2
    max_tokens: int = 2048
    timeout_seconds: int = 120


class EmbeddingConfig(BaseModel):
    base_url: str
    model: str
    api_key: str = ""
    vector_dim: int = 1024
    batch_size: int = 32
    timeout_seconds: int = 120


class RerankerConfig(BaseModel):
    enabled: bool = True
    base_url: str
    model: str = "reranker-model"
    api_key: str = ""
    timeout_seconds: int = 60


class RetrievalConfig(BaseModel):
    top_k: int = 30
    top_n: int = 8
    max_context_chunks: int = 8


class WorkerConfig(BaseModel):
    parse_concurrency: int = 1
    embedding_concurrency: int = 2
    index_concurrency: int = 1
    max_retry: int = 3
    retry_delays_seconds: list[int] = Field(default_factory=lambda: [10, 30, 60])

    @field_validator("retry_delays_seconds")
    @classmethod
    def validate_retry_delays(cls, value: list[int]) -> list[int]:
        if not value:
            raise ValueError("retry_delays_seconds must not be empty")
        return value


class Settings(BaseModel):
    app: AppConfig
    storage: StorageConfig
    postgres: PostgresConfig
    kafka: KafkaConfig
    mineru: MinerUConfig
    milvus: MilvusConfig
    llm: LLMConfig
    embedding: EmbeddingConfig
    reranker: RerankerConfig
    retrieval: RetrievalConfig
    worker: WorkerConfig

    def public_config(self) -> dict[str, Any]:
        data = self.model_dump()
        for section in ("llm", "embedding", "reranker"):
            if section in data:
                data[section].pop("api_key", None)
        data["postgres"].pop("dsn", None)
        return data


@lru_cache
def get_settings() -> Settings:
    config_path = Path(os.getenv("APP_CONFIG_PATH", "config/app.yaml"))
    if not config_path.exists():
        example = config_path.with_suffix(config_path.suffix + ".example")
        raise RuntimeError(f"配置文件不存在: {config_path}. 请复制 config/app.yaml.example 并调整配置。")
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    data = _resolve_env(raw)
    return Settings.model_validate(data)
