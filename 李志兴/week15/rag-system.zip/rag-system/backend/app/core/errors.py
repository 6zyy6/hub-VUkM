class AppError(Exception):
    def __init__(self, code: str, message: str, status_code: int = 400, details: dict | None = None):
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(message)

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "details": self.details}


class NotFoundError(AppError):
    def __init__(self, code: str, message: str, details: dict | None = None):
        super().__init__(code=code, message=message, status_code=404, details=details)


class ConfigError(AppError):
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(code="CONFIG_INVALID", message=message, status_code=500, details=details)
