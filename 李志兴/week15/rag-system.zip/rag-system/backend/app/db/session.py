from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import get_settings

_engine = None
SessionLocal: async_sessionmaker[AsyncSession] | None = None


async def init_db(dsn: str | None = None) -> None:
    global _engine, SessionLocal
    settings = get_settings()
    database_url = dsn or settings.postgres.dsn
    async_url = database_url.replace("postgresql://", "postgresql+asyncpg://", 1)
    _engine = create_async_engine(async_url, pool_pre_ping=True)
    SessionLocal = async_sessionmaker(_engine, expire_on_commit=False)


async def close_db() -> None:
    global _engine
    if _engine is not None:
        await _engine.dispose()


async def get_session() -> AsyncIterator[AsyncSession]:
    if SessionLocal is None:
        await init_db()
    assert SessionLocal is not None
    async with SessionLocal() as session:
        yield session
