from app.core.config import EmbeddingConfig
from app.core.errors import AppError
from app.integrations.http_base import HTTPServiceClient


class EmbeddingClient(HTTPServiceClient):
    def __init__(self, config: EmbeddingConfig):
        super().__init__(config.base_url, config.api_key, config.timeout_seconds)
        self.config = config

    async def embed(self, texts: list[str]) -> list[list[float]]:
        data = await self.post("/embeddings", {"model": self.config.model, "input": texts})
        vectors = [item["embedding"] for item in data.get("data", [])]
        for vector in vectors:
            if len(vector) != self.config.vector_dim:
                raise AppError("EMBEDDING_DIM_MISMATCH", "向量维度与配置不一致", 500, {"expected": self.config.vector_dim, "actual": len(vector)})
        return vectors

    async def test(self) -> dict:
        vectors = await self.embed(["health check"])
        return {"ok": True, "vector_dim": len(vectors[0]) if vectors else 0}
