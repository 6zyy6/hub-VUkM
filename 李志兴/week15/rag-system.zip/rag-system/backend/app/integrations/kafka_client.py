import json
from typing import Any

from aiokafka import AIOKafkaProducer

from app.core.config import KafkaConfig


class KafkaProducerClient:
    def __init__(self, config: KafkaConfig):
        self.config = config
        self._producer: AIOKafkaProducer | None = None

    async def __aenter__(self):
        self._producer = AIOKafkaProducer(bootstrap_servers=self.config.bootstrap_servers)
        await self._producer.start()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self._producer:
            await self._producer.stop()

    async def send_file_task(self, payload: dict[str, Any]) -> None:
        assert self._producer is not None
        await self._producer.send_and_wait(self.config.file_task_topic, json.dumps(payload, ensure_ascii=False).encode("utf-8"))

    async def send_failed_task(self, payload: dict[str, Any]) -> None:
        assert self._producer is not None
        await self._producer.send_and_wait(self.config.file_task_failed_topic, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
