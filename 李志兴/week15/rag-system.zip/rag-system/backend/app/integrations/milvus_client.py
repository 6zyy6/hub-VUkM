from typing import Any

from pymilvus import Collection, CollectionSchema, DataType, FieldSchema, MilvusClient as PyMilvusClient, connections, utility

from app.core.config import MilvusConfig
from app.core.errors import AppError


class MilvusClient:
    def __init__(self, config: MilvusConfig):
        self.config = config
        self.client = PyMilvusClient(uri=config.uri)

    def ensure_collection(self) -> None:
        name = self.config.collection
        if not self.client.has_collection(name):
            schema = self.client.create_schema(auto_id=False, enable_dynamic_field=False)
            schema.add_field("id", DataType.VARCHAR, is_primary=True, max_length=128)
            schema.add_field("chunk_id", DataType.VARCHAR, max_length=128)
            schema.add_field("knowledge_base_id", DataType.VARCHAR, max_length=128)
            schema.add_field("file_id", DataType.VARCHAR, max_length=128)
            schema.add_field("chunk_type", DataType.VARCHAR, max_length=64)
            schema.add_field("page_number", DataType.INT64)
            schema.add_field("created_at", DataType.INT64)
            schema.add_field("embedding", DataType.FLOAT_VECTOR, dim=self.config.vector_dim)
            self.client.create_collection(collection_name=name, schema=schema)
            self.client.create_index(
                collection_name=name,
                field_name="embedding",
                index_params={
                    "index_type": self.config.index_type,
                    "metric_type": self.config.metric_type,
                    "params": {"M": self.config.hnsw.M, "efConstruction": self.config.hnsw.efConstruction},
                },
            )
            return
        desc = self.client.describe_collection(name)
        fields = {field["name"]: field for field in desc.get("fields", [])}
        if "embedding" not in fields or fields["embedding"].get("params", {}).get("dim") != self.config.vector_dim:
            raise AppError("MILVUS_SCHEMA_INVALID", "Milvus Collection 结构与配置不一致，后端不得启动", 500)

    def upsert_vectors(self, rows: list[dict[str, Any]]) -> None:
        if not rows:
            return
        self.client.upsert(collection_name=self.config.collection, data=rows)

    def search(self, vector: list[float], knowledge_base_id: str, top_k: int) -> list[dict[str, Any]]:
        results = self.client.search(
            collection_name=self.config.collection,
            data=[vector],
            anns_field="embedding",
            limit=top_k,
            filter=f'knowledge_base_id == "{knowledge_base_id}"',
            search_params={"metric_type": self.config.metric_type, "params": {"ef": self.config.hnsw.ef}},
            output_fields=["chunk_id", "knowledge_base_id", "file_id", "chunk_type", "page_number"],
        )
        return results[0] if results else []

    def delete_by_file(self, file_id: str) -> None:
        self.client.delete(collection_name=self.config.collection, filter=f'file_id == "{file_id}"')

    def delete_by_kb(self, knowledge_base_id: str) -> None:
        self.client.delete(collection_name=self.config.collection, filter=f'knowledge_base_id == "{knowledge_base_id}"')

    def health(self) -> dict[str, Any]:
        return {"ok": self.client.has_collection(self.config.collection)}
