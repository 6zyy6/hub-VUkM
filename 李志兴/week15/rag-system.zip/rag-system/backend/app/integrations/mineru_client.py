from pathlib import Path
from typing import Any

import httpx

from app.core.config import MinerUConfig


class MinerUClient:
    def __init__(self, config: MinerUConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")

    async def parse_file(self, file_path: Path, output_dir: Path) -> dict[str, Any]:
        output_dir.mkdir(parents=True, exist_ok=True)
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            with file_path.open("rb") as fh:
                files = {"file": (file_path.name, fh)}
                resp = await client.post(f"{self.base_url}/parse", files=files, data={"output_dir": str(output_dir)})
                resp.raise_for_status()
                data = resp.json()
        return data

    async def health(self) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{self.base_url}/health")
            resp.raise_for_status()
            return resp.json()
