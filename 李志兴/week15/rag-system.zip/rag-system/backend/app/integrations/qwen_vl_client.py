import base64
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

import httpx

from app.core.config import LLMConfig


class QwenVLClient:
    def __init__(self, config: LLMConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")

    def headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers

    @staticmethod
    def image_to_data_url(path: Path) -> str:
        data = base64.b64encode(path.read_bytes()).decode("ascii")
        suffix = path.suffix.lower().lstrip(".") or "png"
        if suffix == "jpg":
            suffix = "jpeg"
        return f"data:image/{suffix};base64,{data}"

    async def stream_chat(self, prompt: str, image_paths: list[Path] | None = None) -> AsyncIterator[str]:
        content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        for path in image_paths or []:
            content.append({"type": "image_url", "image_url": {"url": self.image_to_data_url(path)}})
        payload = {
            "model": self.config.model,
            "messages": [{"role": "user", "content": content}],
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "stream": True,
        }
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            async with client.stream("POST", f"{self.base_url}/chat/completions", json=payload, headers=self.headers()) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data = line.removeprefix("data: ").strip()
                    if data == "[DONE]":
                        break
                    yield data

    async def test(self) -> dict:
        # 不发送真实问答，只验证模型服务 endpoint 是否可达。
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            resp = await client.get(f"{self.base_url}/models", headers=self.headers())
            resp.raise_for_status()
        return {"ok": True}
