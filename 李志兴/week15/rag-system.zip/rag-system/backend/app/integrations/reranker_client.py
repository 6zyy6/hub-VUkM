from typing import Any

from app.core.config import RerankerConfig
from app.integrations.http_base import HTTPServiceClient


class RerankerClient(HTTPServiceClient):
    def __init__(self, config: RerankerConfig):
        super().__init__(config.base_url, config.api_key, config.timeout_seconds)
        self.config = config

    async def rerank(self, query: str, documents: list[dict[str, Any]], top_n: int) -> list[dict[str, Any]]:
        return (await self.post("/rerank", {"query": query, "documents": documents, "top_n": top_n})).get("results", [])

    async def test(self) -> dict:
        docs = [{"chunk_id": "test", "content": "health check", "metadata": {}}]
        await self.rerank("health", docs, 1)
        return {"ok": True}
