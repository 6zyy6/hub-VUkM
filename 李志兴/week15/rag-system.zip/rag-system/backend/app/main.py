from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from app.api.v1.router import api_router
from app.core.config import get_settings
from app.core.errors import AppError
from app.core.logging import configure_logging, get_logger
from app.db.session import close_db, init_db
from app.integrations.milvus_client import MilvusClient
from app.utils.storage import ensure_storage_dirs
from app.utils.prompts import validate_prompt_templates

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    settings = get_settings()
    ensure_storage_dirs(settings.storage)
    validate_prompt_templates()
    await init_db(settings.postgres.dsn)
    milvus = MilvusClient(settings.milvus)
    milvus.ensure_collection()
    logger.info("application_started", env=settings.app.env)
    yield
    await close_db()
    logger.info("application_stopped")


settings = get_settings()
app = FastAPI(title="Multimodal RAG System", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(AppError)
async def app_error_handler(_: Request, exc: AppError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content=exc.to_dict())


@app.exception_handler(Exception)
async def unexpected_error_handler(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("unexpected_error", error=str(exc))
    return JSONResponse(
        status_code=500,
        content={"code": "SYSTEM_INTERNAL_ERROR", "message": "系统内部错误", "details": {}},
    )


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/metrics")
async def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


app.include_router(api_router, prefix=settings.app.api_prefix)
