from enum import StrEnum


class FileStatus(StrEnum):
    uploading = "uploading"
    pending_parse = "pending_parse"
    parsing = "parsing"
    chunking = "chunking"
    embedding = "embedding"
    indexing = "indexing"
    completed = "completed"
    failed = "failed"


class TaskStatus(StrEnum):
    pending = "pending"
    running = "running"
    retrying = "retrying"
    completed = "completed"
    failed = "failed"


class TaskStep(StrEnum):
    pending_parse = "pending_parse"
    parsing = "parsing"
    chunking = "chunking"
    previewing = "previewing"
    embedding = "embedding"
    indexing = "indexing"
    completed = "completed"


class ChunkType(StrEnum):
    text = "text"
    table = "table"
    image = "image"
    ocr = "ocr"
    formula = "formula"
    layout = "layout"


class AssetType(StrEnum):
    pdf_page_preview = "pdf_page_preview"
    pdf_crop = "pdf_crop"
    image_original = "image_original"
    table_preview = "table_preview"
    other = "other"


class MessageStatus(StrEnum):
    generating = "generating"
    completed = "completed"
    failed = "failed"
