from typing import Any

from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession


async def paginate(session: AsyncSession, stmt: Select[Any], page: int, page_size: int) -> dict[str, Any]:
    total_stmt = select(func.count()).select_from(stmt.subquery())
    total = await session.scalar(total_stmt)
    rows = (await session.scalars(stmt.offset((page - 1) * page_size).limit(page_size))).all()
    return {"items": rows, "total": total or 0, "page": page, "page_size": page_size}
