from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import NotFoundError
from app.models.entities import ChunkAsset, DocumentChunk, File, FileTask


class FileRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, file_id: UUID) -> File:
        item = await self.session.get(File, file_id)
        if not item:
            raise NotFoundError("FILE_NOT_FOUND", "文件不存在", {"file_id": str(file_id)})
        return item

    async def list_by_kb(self, kb_id: UUID) -> list[File]:
        return list((await self.session.scalars(select(File).where(File.knowledge_base_id == kb_id).order_by(File.created_at.desc()))).all())

    async def list_tasks(self, file_id: UUID) -> list[FileTask]:
        return list((await self.session.scalars(select(FileTask).where(FileTask.file_id == file_id).order_by(FileTask.created_at.desc()))).all())

    async def get_task(self, task_id: UUID) -> FileTask:
        task = await self.session.get(FileTask, task_id)
        if not task:
            raise NotFoundError("TASK_NOT_FOUND", "任务不存在", {"task_id": str(task_id)})
        return task

    async def list_chunks(self, file_id: UUID) -> list[DocumentChunk]:
        return list((await self.session.scalars(select(DocumentChunk).where(DocumentChunk.file_id == file_id).order_by(DocumentChunk.chunk_index))).all())

    async def get_chunk(self, chunk_id: UUID) -> DocumentChunk:
        chunk = await self.session.get(DocumentChunk, chunk_id)
        if not chunk:
            raise NotFoundError("FILE_CHUNK_NOT_FOUND", "内容块不存在", {"chunk_id": str(chunk_id)})
        return chunk

    async def get_asset(self, asset_id: UUID) -> ChunkAsset:
        asset = await self.session.get(ChunkAsset, asset_id)
        if not asset:
            raise NotFoundError("FILE_ASSET_NOT_FOUND", "资源不存在", {"asset_id": str(asset_id)})
        return asset
