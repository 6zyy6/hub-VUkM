from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import NotFoundError
from app.models.entities import KnowledgeBase


class KnowledgeBaseRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, name: str, description: str | None) -> KnowledgeBase:
        kb = KnowledgeBase(name=name, description=description)
        self.session.add(kb)
        await self.session.flush()
        return kb

    async def list(self) -> list[KnowledgeBase]:
        return list((await self.session.scalars(select(KnowledgeBase).order_by(KnowledgeBase.created_at.desc()))).all())

    async def get(self, kb_id: UUID) -> KnowledgeBase:
        kb = await self.session.get(KnowledgeBase, kb_id)
        if not kb:
            raise NotFoundError("KB_NOT_FOUND", "知识库不存在", {"knowledge_base_id": str(kb_id)})
        return kb

    async def delete(self, kb_id: UUID) -> KnowledgeBase:
        kb = await self.get(kb_id)
        await self.session.delete(kb)
        return kb
