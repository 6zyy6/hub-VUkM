from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import NotFoundError
from app.models.entities import QAMessage, QAMessageReference, QASession


class QARepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create_session(self, kb_id: UUID, title: str) -> QASession:
        session = QASession(knowledge_base_id=kb_id, title=title)
        self.session.add(session)
        await self.session.flush()
        return session

    async def list_sessions(self, kb_id: UUID) -> list[QASession]:
        return list((await self.session.scalars(select(QASession).where(QASession.knowledge_base_id == kb_id).order_by(QASession.updated_at.desc()))).all())

    async def get_session(self, session_id: UUID) -> QASession:
        item = await self.session.get(QASession, session_id)
        if not item:
            raise NotFoundError("KB_SESSION_NOT_FOUND", "问答会话不存在", {"session_id": str(session_id)})
        return item

    async def list_messages(self, session_id: UUID) -> list[QAMessage]:
        return list((await self.session.scalars(select(QAMessage).where(QAMessage.session_id == session_id).order_by(QAMessage.created_at))).all())

    async def get_message(self, message_id: UUID) -> QAMessage:
        item = await self.session.get(QAMessage, message_id)
        if not item:
            raise NotFoundError("KB_MESSAGE_NOT_FOUND", "问答消息不存在", {"message_id": str(message_id)})
        return item

    async def list_references(self, message_id: UUID) -> list[QAMessageReference]:
        return list((await self.session.scalars(select(QAMessageReference).where(QAMessageReference.message_id == message_id).order_by(QAMessageReference.reference_index))).all())

    async def get_reference(self, reference_id: UUID) -> QAMessageReference:
        item = await self.session.get(QAMessageReference, reference_id)
        if not item:
            raise NotFoundError("KB_REFERENCE_NOT_FOUND", "引用来源不存在", {"reference_id": str(reference_id)})
        return item
