from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class FileRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    knowledge_base_id: UUID
    original_name: str
    file_ext: str
    mime_type: str | None
    file_size: int
    status: str
    error_message: str | None
    page_count: int | None
    created_at: datetime
    updated_at: datetime


class FileTaskRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    file_id: UUID
    knowledge_base_id: UUID
    current_step: str
    status: str
    retry_count: int
    max_retry: int
    next_retry_at: datetime | None
    error_code: str | None
    error_message: str | None
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    updated_at: datetime


class ChunkRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    knowledge_base_id: UUID
    file_id: UUID
    chunk_index: int
    chunk_type: str
    title_path: Any | None
    content_text: str
    content_summary: str | None
    page_number: int | None
    bbox: Any | None
    sheet_name: str | None
    row_range: str | None
    col_range: str | None
    table_id: str | None
    milvus_vector_id: str | None
    metadata: dict[str, Any] = Field(validation_alias="metadata_", serialization_alias="metadata")
    created_at: datetime
    updated_at: datetime


class AssetRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    chunk_id: UUID
    file_id: UUID
    asset_type: str
    asset_path: str
    page_number: int | None
    bbox: Any | None
    metadata: dict[str, Any] = Field(validation_alias="metadata_", serialization_alias="metadata")
    created_at: datetime
