from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class SessionCreate(BaseModel):
    title: str = "新会话"


class SessionUpdate(BaseModel):
    title: str


class SessionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    knowledge_base_id: UUID
    title: str
    created_at: datetime
    updated_at: datetime


class QuestionCreate(BaseModel):
    question: str


class MessageRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    session_id: UUID
    knowledge_base_id: UUID
    question: str
    answer: str | None
    status: str
    retrieved_chunks: Any | None
    model_config_snapshot: dict[str, Any] | None
    error_message: str | None
    created_at: datetime
    updated_at: datetime


class ReferenceRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    message_id: UUID
    chunk_id: UUID
    file_id: UUID
    reference_index: int
    quote_text: str | None
    page_number: int | None
    bbox: Any | None
    asset_id: UUID | None
    metadata: dict[str, Any] = Field(validation_alias="metadata_", serialization_alias="metadata")
    created_at: datetime
