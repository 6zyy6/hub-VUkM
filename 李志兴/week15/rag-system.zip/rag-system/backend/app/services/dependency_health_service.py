from app.core.config import get_settings
from app.integrations.embedding_client import EmbeddingClient
from app.integrations.milvus_client import MilvusClient
from app.integrations.mineru_client import MinerUClient
from app.integrations.qwen_vl_client import QwenVLClient
from app.integrations.reranker_client import RerankerClient


class DependencyHealthService:
    def __init__(self):
        self.settings = get_settings()

    async def check_dependencies(self) -> dict:
        checks: dict[str, dict] = {}
        for name, fn in {
            "milvus": lambda: MilvusClient(self.settings.milvus).health(),
            "mineru": lambda: MinerUClient(self.settings.mineru).health(),
            "embedding": lambda: EmbeddingClient(self.settings.embedding).test(),
            "reranker": lambda: RerankerClient(self.settings.reranker).test() if self.settings.reranker.enabled else {"ok": True, "disabled": True},
            "llm": lambda: QwenVLClient(self.settings.llm).test(),
        }.items():
            try:
                result = fn()
                if hasattr(result, "__await__"):
                    result = await result
                checks[name] = {"ok": True, "result": result}
            except Exception as exc:
                checks[name] = {"ok": False, "error": str(exc)}
        return checks
