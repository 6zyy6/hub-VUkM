import uuid
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from fastapi import UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.integrations.kafka_client import KafkaProducerClient
from app.integrations.milvus_client import MilvusClient
from app.models.entities import File, FileTask
from app.models.enums import FileStatus, TaskStatus, TaskStep
from app.repositories.files import FileRepository
from app.repositories.knowledge_bases import KnowledgeBaseRepository
from app.utils.storage import remove_path, save_upload_file


class FileService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.settings = get_settings()
        self.files = FileRepository(session)
        self.kbs = KnowledgeBaseRepository(session)

    async def upload_files(self, knowledge_base_id: UUID, uploads: list[UploadFile]) -> list[File]:
        await self.kbs.get(knowledge_base_id)
        created: list[File] = []
        async with KafkaProducerClient(self.settings.kafka) as producer:
            for upload in uploads:
                path, size, ext = await save_upload_file(upload, self.settings.storage, knowledge_base_id)
                parsed_dir = Path(self.settings.storage.parsed_dir) / str(knowledge_base_id) / path.stem
                preview_dir = Path(self.settings.storage.previews_dir) / str(knowledge_base_id) / path.stem
                item = File(
                    knowledge_base_id=knowledge_base_id,
                    original_name=upload.filename or path.name,
                    file_ext=ext,
                    mime_type=upload.content_type,
                    file_size=size,
                    original_path=str(path),
                    parsed_dir=str(parsed_dir),
                    preview_dir=str(preview_dir),
                    status=FileStatus.pending_parse.value,
                    file_metadata={},
                )
                self.session.add(item)
                await self.session.flush()
                task = FileTask(
                    file_id=item.id,
                    knowledge_base_id=knowledge_base_id,
                    current_step=TaskStep.pending_parse.value,
                    status=TaskStatus.pending.value,
                    retry_count=0,
                    max_retry=self.settings.worker.max_retry,
                )
                self.session.add(task)
                await self.session.flush()
                payload = {
                    "trace_id": str(uuid.uuid4()),
                    "task_id": str(task.id),
                    "file_id": str(item.id),
                    "knowledge_base_id": str(knowledge_base_id),
                    "step": task.current_step,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
                await producer.send_file_task(payload)
                created.append(item)
        await self.session.commit()
        for item in created:
            await self.session.refresh(item)
        return created

    async def list_by_kb(self, kb_id: UUID) -> list[File]:
        await self.kbs.get(kb_id)
        return await self.files.list_by_kb(kb_id)

    async def get(self, file_id: UUID) -> File:
        return await self.files.get(file_id)

    async def delete(self, file_id: UUID) -> None:
        item = await self.files.get(file_id)
        MilvusClient(self.settings.milvus).delete_by_file(str(file_id))
        remove_path(item.original_path)
        remove_path(item.parsed_dir)
        remove_path(item.preview_dir)
        await self.session.delete(item)
        await self.session.commit()

    async def retry(self, file_id: UUID) -> FileTask:
        item = await self.files.get(file_id)
        item.status = FileStatus.pending_parse.value
        item.error_message = None
        task = FileTask(
            file_id=item.id,
            knowledge_base_id=item.knowledge_base_id,
            current_step=TaskStep.pending_parse.value,
            status=TaskStatus.pending.value,
            retry_count=0,
            max_retry=self.settings.worker.max_retry,
        )
        self.session.add(task)
        await self.session.flush()
        async with KafkaProducerClient(self.settings.kafka) as producer:
            await producer.send_file_task({
                "trace_id": str(uuid.uuid4()),
                "task_id": str(task.id),
                "file_id": str(item.id),
                "knowledge_base_id": str(item.knowledge_base_id),
                "step": task.current_step,
            })
        await self.session.commit()
        await self.session.refresh(task)
        return task
