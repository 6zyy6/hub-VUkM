from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.integrations.milvus_client import MilvusClient
from app.models.entities import KnowledgeBase
from app.repositories.knowledge_bases import KnowledgeBaseRepository
from app.utils.storage import remove_path
from app.core.config import get_settings


class KnowledgeBaseService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.repo = KnowledgeBaseRepository(session)
        self.settings = get_settings()

    async def create(self, name: str, description: str | None) -> KnowledgeBase:
        kb = await self.repo.create(name=name, description=description)
        await self.session.commit()
        await self.session.refresh(kb)
        return kb

    async def list(self) -> list[KnowledgeBase]:
        return await self.repo.list()

    async def get(self, kb_id: UUID) -> KnowledgeBase:
        return await self.repo.get(kb_id)

    async def update(self, kb_id: UUID, name: str | None, description: str | None) -> KnowledgeBase:
        kb = await self.repo.get(kb_id)
        if name is not None:
            kb.name = name
        if description is not None:
            kb.description = description
        await self.session.commit()
        await self.session.refresh(kb)
        return kb

    async def delete(self, kb_id: UUID) -> None:
        kb = await self.repo.get(kb_id)
        files = list(kb.files)
        MilvusClient(self.settings.milvus).delete_by_kb(str(kb_id))
        for f in files:
            remove_path(f.original_path)
            remove_path(f.parsed_dir)
            remove_path(f.preview_dir)
        await self.session.delete(kb)
        await self.session.commit()
