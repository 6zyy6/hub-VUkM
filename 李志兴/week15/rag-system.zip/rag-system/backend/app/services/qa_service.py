import json
from collections.abc import AsyncIterator
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.integrations.embedding_client import EmbeddingClient
from app.integrations.milvus_client import MilvusClient
from app.integrations.qwen_vl_client import QwenVLClient
from app.integrations.reranker_client import RerankerClient
from app.models.entities import ChunkAsset, DocumentChunk, File, QAMessage, QAMessageReference
from app.models.enums import AssetType, MessageStatus
from app.repositories.qa import QARepository
from app.utils.prompts import load_prompt, render_prompt
from app.utils.sse import sse_event


class QAService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.repo = QARepository(session)
        self.settings = get_settings()

    async def create_session(self, kb_id: UUID, title: str):
        item = await self.repo.create_session(kb_id, title)
        await self.session.commit()
        await self.session.refresh(item)
        return item

    async def update_session(self, session_id: UUID, title: str):
        item = await self.repo.get_session(session_id)
        item.title = title
        await self.session.commit()
        await self.session.refresh(item)
        return item

    async def delete_session(self, session_id: UUID) -> None:
        item = await self.repo.get_session(session_id)
        await self.session.delete(item)
        await self.session.commit()

    async def stream_answer(self, session_id: UUID, question: str) -> AsyncIterator[str]:
        qa_session = await self.repo.get_session(session_id)
        msg = QAMessage(
            session_id=session_id,
            knowledge_base_id=qa_session.knowledge_base_id,
            question=question,
            status=MessageStatus.generating.value,
            retrieved_chunks=[],
            model_config_snapshot=self.settings.public_config(),
        )
        self.session.add(msg)
        await self.session.commit()
        await self.session.refresh(msg)
        yield sse_event("message_start", {"message_id": str(msg.id)})
        try:
            yield sse_event("retrieval_start", {"top_k": self.settings.retrieval.top_k})
            chunks = await self._retrieve(question, qa_session.knowledge_base_id)
            yield sse_event("retrieval_done", {"count": len(chunks)})
            if not chunks:
                answer = load_prompt("insufficient_context.md").strip()
                msg.answer = answer
                msg.status = MessageStatus.completed.value
                msg.retrieved_chunks = []
                await self.session.commit()
                yield sse_event("answer_delta", {"text": answer})
                yield sse_event("references", [])
                yield sse_event("message_done", {"message_id": str(msg.id)})
                return

            context_text = self._format_context(chunks)
            prompt = render_prompt(load_prompt("rag_answer.md"), question=question, context=context_text)
            image_assets = await self._select_visual_assets(chunks)
            answer_parts: list[str] = []
            async for raw in QwenVLClient(self.settings.llm).stream_chat(prompt, image_assets):
                delta = self._parse_openai_delta(raw)
                if not delta:
                    continue
                answer_parts.append(delta)
                yield sse_event("answer_delta", {"text": delta})
            answer = "".join(answer_parts).strip()
            references = await self._save_references(msg, chunks)
            msg.answer = answer or load_prompt("insufficient_context.md").strip()
            msg.status = MessageStatus.completed.value
            msg.retrieved_chunks = [self._chunk_snapshot(chunk) for chunk in chunks]
            await self.session.commit()
            yield sse_event("references", references)
            yield sse_event("message_done", {"message_id": str(msg.id)})
        except Exception as exc:
            msg.status = MessageStatus.failed.value
            msg.error_message = str(exc)
            await self.session.commit()
            yield sse_event("error", {"code": "LLM_GENERATION_FAILED", "message": str(exc), "details": {"message_id": str(msg.id)}})

    async def _retrieve(self, question: str, knowledge_base_id: UUID) -> list[DocumentChunk]:
        vectors = await EmbeddingClient(self.settings.embedding).embed([question])
        hits = MilvusClient(self.settings.milvus).search(vectors[0], str(knowledge_base_id), self.settings.retrieval.top_k)
        chunk_ids = [UUID(hit["entity"]["chunk_id"]) if isinstance(hit, dict) and "entity" in hit else UUID(hit["chunk_id"]) for hit in hits]
        if not chunk_ids:
            return []
        db_chunks = list((await self.session.scalars(select(DocumentChunk).where(DocumentChunk.id.in_(chunk_ids)))).all())
        by_id = {str(c.id): c for c in db_chunks}
        ordered = [by_id[str(cid)] for cid in chunk_ids if str(cid) in by_id]
        if self.settings.reranker.enabled and ordered:
            docs = [{"chunk_id": str(c.id), "content": c.content_text, "metadata": self._chunk_snapshot(c)} for c in ordered]
            reranked = await RerankerClient(self.settings.reranker).rerank(question, docs, self.settings.retrieval.top_n)
            ids = [item["chunk_id"] for item in reranked if item.get("chunk_id") in by_id]
            ordered = [by_id[i] for i in ids]
        else:
            ordered = ordered[: self.settings.retrieval.top_n]
        return ordered[: self.settings.retrieval.max_context_chunks]

    def _format_context(self, chunks: list[DocumentChunk]) -> str:
        lines: list[str] = []
        for idx, chunk in enumerate(chunks, start=1):
            loc = f"page={chunk.page_number}" if chunk.page_number else "page=null"
            table = f", sheet={chunk.sheet_name}, rows={chunk.row_range}, cols={chunk.col_range}" if chunk.chunk_type == "table" else ""
            lines.append(f"[{idx}] chunk_id={chunk.id}, type={chunk.chunk_type}, {loc}{table}\n{chunk.content_text}")
        return "\n\n".join(lines)

    async def _select_visual_assets(self, chunks: list[DocumentChunk]):
        visual_types = {AssetType.pdf_crop.value, AssetType.image_original.value}
        rows = (await self.session.scalars(select(ChunkAsset).where(ChunkAsset.chunk_id.in_([c.id for c in chunks])))).all()
        selected = [asset.asset_path for asset in rows if asset.asset_type in visual_types][:8]
        from pathlib import Path
        return [Path(path) for path in selected]

    async def _save_references(self, msg: QAMessage, chunks: list[DocumentChunk]) -> list[dict]:
        refs = []
        for idx, chunk in enumerate(chunks, start=1):
            asset = await self.session.scalar(select(ChunkAsset).where(ChunkAsset.chunk_id == chunk.id).limit(1))
            ref = QAMessageReference(
                message_id=msg.id,
                chunk_id=chunk.id,
                file_id=chunk.file_id,
                reference_index=idx,
                quote_text=(chunk.content_summary or chunk.content_text[:300]),
                page_number=chunk.page_number,
                bbox=chunk.bbox,
                asset_id=asset.id if asset else None,
                metadata_={"chunk_type": chunk.chunk_type, "table_id": chunk.table_id, "sheet_name": chunk.sheet_name, "row_range": chunk.row_range, "col_range": chunk.col_range},
            )
            self.session.add(ref)
            await self.session.flush()
            file = await self.session.get(File, chunk.file_id)
            refs.append({
                "id": str(ref.id),
                "reference_index": idx,
                "knowledge_base_id": str(chunk.knowledge_base_id),
                "file_id": str(chunk.file_id),
                "file_name": file.original_name if file else None,
                "chunk_id": str(chunk.id),
                "chunk_type": chunk.chunk_type,
                "page_number": chunk.page_number,
                "quote_text": ref.quote_text,
                "asset_id": str(ref.asset_id) if ref.asset_id else None,
            })
        return refs

    def _chunk_snapshot(self, chunk: DocumentChunk) -> dict:
        return {
            "chunk_id": str(chunk.id),
            "file_id": str(chunk.file_id),
            "knowledge_base_id": str(chunk.knowledge_base_id),
            "chunk_type": chunk.chunk_type,
            "page_number": chunk.page_number,
            "bbox": chunk.bbox,
            "sheet_name": chunk.sheet_name,
            "row_range": chunk.row_range,
            "col_range": chunk.col_range,
            "table_id": chunk.table_id,
        }

    @staticmethod
    def _parse_openai_delta(raw: str) -> str:
        try:
            payload = json.loads(raw)
            return payload.get("choices", [{}])[0].get("delta", {}).get("content", "") or ""
        except json.JSONDecodeError:
            return ""
