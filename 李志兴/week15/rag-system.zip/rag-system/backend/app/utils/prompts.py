from pathlib import Path

from app.core.errors import ConfigError

PROMPT_DIR = Path("config/prompts")
REQUIRED_PROMPTS = ["rag_answer.md", "insufficient_context.md"]


def validate_prompt_templates() -> None:
    missing = [name for name in REQUIRED_PROMPTS if not (PROMPT_DIR / name).exists()]
    if missing:
        raise ConfigError("必需 Prompt 模板文件不存在", {"missing": missing})


def load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise ConfigError("Prompt 模板不存在", {"name": name})
    return path.read_text(encoding="utf-8")


def render_prompt(template: str, **kwargs: str) -> str:
    rendered = template
    for key, value in kwargs.items():
        rendered = rendered.replace("{{ " + key + " }}", value)
    return rendered
