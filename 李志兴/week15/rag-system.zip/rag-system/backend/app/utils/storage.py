import shutil
import uuid
from pathlib import Path

from fastapi import UploadFile

from app.core.config import StorageConfig
from app.core.errors import AppError

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".docx", ".pptx", ".xlsx"}


def ensure_storage_dirs(config: StorageConfig) -> None:
    for path in [config.root_dir, config.originals_dir, config.parsed_dir, config.previews_dir, config.temp_dir]:
        Path(path).mkdir(parents=True, exist_ok=True)


def validate_upload_filename(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise AppError("FILE_UNSUPPORTED_TYPE", "文件类型不在第一版支持范围内", 400, {"file_ext": ext})
    return ext


async def save_upload_file(upload: UploadFile, storage: StorageConfig, kb_id: uuid.UUID) -> tuple[Path, int, str]:
    ext = validate_upload_filename(upload.filename or "")
    target_dir = Path(storage.originals_dir) / str(kb_id)
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / f"{uuid.uuid4()}{ext}"
    size = 0
    with target.open("wb") as out:
      while chunk := await upload.read(1024 * 1024):
          size += len(chunk)
          out.write(chunk)
    return target, size, ext


def safe_asset_path(path: str, storage: StorageConfig) -> Path:
    root = Path(storage.root_dir).resolve()
    target = Path(path).resolve()
    if root not in target.parents and target != root:
        raise AppError("FILE_FORBIDDEN_PATH", "禁止访问受控存储目录之外的文件", 403)
    if not target.exists():
        raise AppError("FILE_ASSET_NOT_FOUND", "预览资源不存在", 404)
    return target


def remove_path(path: str | None) -> None:
    if not path:
        return
    p = Path(path)
    if p.is_dir():
        shutil.rmtree(p, ignore_errors=True)
    elif p.exists():
        p.unlink(missing_ok=True)
