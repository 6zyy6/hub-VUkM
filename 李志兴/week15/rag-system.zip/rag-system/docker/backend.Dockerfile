FROM python:3.11-slim
WORKDIR /app
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
RUN apt-get update && apt-get install -y --no-install-recommends build-essential curl poppler-utils && rm -rf /var/lib/apt/lists/*
COPY backend /app/backend
RUN pip install --no-cache-dir -e /app/backend
COPY config /app/config
WORKDIR /app/backend
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
