# API 清单

统一前缀：`/api/v1`。

## 健康检查与配置

| 方法 | 路径 | 用途 |
|---|---|---|
| GET | `/health` | 基础健康检查 |
| GET | `/api/v1/health/dependencies` | 依赖健康检查 |
| GET | `/api/v1/config/public` | 查看非敏感配置 |
| POST | `/api/v1/config/model-services/test` | 测试模型服务连通性 |

## 知识库

| 方法 | 路径 | 用途 |
|---|---|---|
| POST | `/api/v1/knowledge-bases` | 创建知识库 |
| GET | `/api/v1/knowledge-bases` | 获取知识库列表 |
| GET | `/api/v1/knowledge-bases/{knowledge_base_id}` | 获取详情 |
| PATCH | `/api/v1/knowledge-bases/{knowledge_base_id}` | 更新名称或描述 |
| DELETE | `/api/v1/knowledge-bases/{knowledge_base_id}` | 删除知识库 |

## 文件、任务、内容块、问答

以 `项目方案.md` 第 23 章为准，当前代码已按清单实现第一版接口路径。
