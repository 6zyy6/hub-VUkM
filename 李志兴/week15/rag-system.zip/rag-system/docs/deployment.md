# 本地部署说明

## 1. 准备配置

```bash
cp .env.example .env
cp config/app.yaml.example config/app.yaml
bash scripts/init-storage.sh
```

编辑 `config/app.yaml`，配置外部 Qwen-VL、Embedding、Reranker 服务地址、模型名称、API Key、向量维度和超时时间。

## 2. 启动主服务

```bash
docker compose up -d --build
```

主服务包括：

- PostgreSQL
- Milvus etcd
- Milvus MinIO
- Milvus standalone
- Kafka
- MinerU
- backend
- worker
- frontend

Qwen-VL、Embedding、Reranker 不由主 Compose 启动。

## 3. 数据库迁移

```bash
docker compose exec backend alembic upgrade head
```

## 4. 访问

- 前端：`http://localhost:5173`
- 后端 OpenAPI：`http://localhost:8000/docs`
- 健康检查：`http://localhost:8000/health`

## 5. 注意事项

MinerU 本地服务的 Docker 镜像和启动命令可能需要按实际 MinerU 部署方式调整。项目约束是本地 HTTP 服务接入，不接入 MinerU 官方 API。
