# 错误码说明

HTTP API 错误响应格式：

```json
{
  "code": "ERROR_CODE",
  "message": "错误描述",
  "details": {}
}
```

SSE 错误事件格式：

```json
{
  "event": "error",
  "data": {
    "code": "ERROR_CODE",
    "message": "错误描述",
    "details": {}
  }
}
```

## 分类

| 前缀 | 说明 |
|---|---|
| `KB_` | 知识库错误 |
| `FILE_` | 文件错误 |
| `TASK_` | 任务错误 |
| `MINERU_` | MinerU 错误 |
| `EMBEDDING_` | 向量化错误 |
| `MILVUS_` | Milvus 错误 |
| `RERANKER_` | Reranker 错误 |
| `LLM_` | Qwen-VL 错误 |
| `CONFIG_` | 配置错误 |
| `SYSTEM_` | 系统错误 |

## 已实现错误码

| 错误码 | 说明 |
|---|---|
| `KB_NOT_FOUND` | 知识库不存在 |
| `KB_SESSION_NOT_FOUND` | 问答会话不存在 |
| `KB_MESSAGE_NOT_FOUND` | 问答消息不存在 |
| `KB_REFERENCE_NOT_FOUND` | 引用来源不存在 |
| `FILE_NOT_FOUND` | 文件不存在 |
| `FILE_UNSUPPORTED_TYPE` | 上传文件类型不支持 |
| `FILE_CHUNK_NOT_FOUND` | 内容块不存在 |
| `FILE_ASSET_NOT_FOUND` | 预览资源不存在 |
| `FILE_FORBIDDEN_PATH` | 禁止访问受控存储目录之外的文件 |
| `TASK_NOT_FOUND` | 文件任务不存在 |
| `MINERU_PARSE_FAILED` | MinerU 解析失败 |
| `TASK_CHUNKING_FAILED` | 内容切分失败 |
| `TASK_PREVIEW_FAILED` | 预览资源生成失败 |
| `EMBEDDING_FAILED` | 向量化失败 |
| `EMBEDDING_DIM_MISMATCH` | Embedding 向量维度与配置不一致 |
| `MILVUS_INDEX_FAILED` | Milvus 索引写入失败 |
| `MILVUS_SCHEMA_INVALID` | Milvus Collection 结构与配置不一致 |
| `LLM_GENERATION_FAILED` | Qwen-VL 生成失败 |
| `CONFIG_INVALID` | 配置或 Prompt 模板不合法 |
| `SYSTEM_INTERNAL_ERROR` | 系统内部错误 |
