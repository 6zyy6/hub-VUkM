# 模型服务接入说明

第一版主 Docker Compose 不启动 Qwen-VL、Embedding、Reranker。三类模型服务均作为外部可配置 HTTP 服务接入。

## Qwen-VL 多模态 Chat 服务

接口风格：OpenAI-compatible Chat Completions。

默认路径：

```http
POST /v1/chat/completions
```

后端要求：

- 支持 `model`、`messages`、`temperature`、`max_tokens`、`stream`。
- 支持文本输入和图片输入。
- 图片输入使用 base64 data URL。
- 支持流式响应，后端会转换为前端 SSE。

配置位置：`config/app.yaml` 的 `llm` 段。

## Embedding 服务

接口风格：OpenAI-compatible Embeddings。

默认路径：

```http
POST /v1/embeddings
```

请求字段：

```json
{
  "model": "embedding-model",
  "input": ["text"]
}
```

响应必须包含向量数组。后端会校验向量维度是否等于 `embedding.vector_dim`。

更换 embedding 模型或向量维度后，已有知识库必须重新向量化并重建索引。

## Reranker 服务

默认路径：

```http
POST /rerank
```

请求字段：

```json
{
  "query": "用户问题",
  "documents": [
    {"chunk_id": "...", "content": "...", "metadata": {}}
  ],
  "top_n": 8
}
```

响应字段：

```json
{
  "results": [
    {"chunk_id": "...", "score": 0.9}
  ]
}
```

Reranker 启用时，失败会导致问答请求失败；关闭时直接使用 Milvus 召回排序结果。

## 连通性测试

```http
POST /api/v1/config/model-services/test
```

检测范围：Qwen-VL、Embedding、Reranker，包含 Embedding 向量维度一致性检测。
