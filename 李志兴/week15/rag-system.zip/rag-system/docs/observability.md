# 日志与运行监控

## 结构化日志

后端和 Worker 输出 JSON 结构化日志，字段包括：

- `timestamp`
- `level`
- `trace_id`
- `request_id`
- `task_id`
- `knowledge_base_id`
- `file_id`
- `message`
- `error_code`
- `duration_ms`

日志不得输出 API Key、完整 Authorization Header 和模型服务密钥。

## Kafka 追踪字段

文件处理任务消息包含：

- `trace_id`
- `task_id`
- `file_id`
- `knowledge_base_id`
- `step`

## Prometheus 指标

后端暴露：

```http
GET /metrics
```

## 健康检查

基础健康检查：

```http
GET /health
```

依赖健康检查：

```http
GET /api/v1/health/dependencies
```

检查范围：PostgreSQL、Kafka、Milvus、MinerU、本地存储目录、Qwen-VL、Embedding、Reranker。当前代码已提供 Milvus、MinerU 和模型服务连通性检查；PostgreSQL 与 Kafka 可在后续通过连接池 ping 和生产者 metadata 请求补充。
