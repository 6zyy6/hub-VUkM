import { useEffect, useMemo, useState } from 'react';
import { Button, Card, Drawer, Empty, Flex, Input, Layout, List, message, Modal, Space, Tag, Typography, Upload } from 'antd';
import { DeleteOutlined, FileAddOutlined, PlusOutlined, ReloadOutlined, SendOutlined } from '@ant-design/icons';
import type { UploadFile } from 'antd';
import { api } from './api/client';
import type { FileItem, KnowledgeBase, PreviewData, QAMessage, QASession, ReferenceItem } from './types/api';

const { Sider, Content } = Layout;
const { Text, Title, Paragraph } = Typography;

export default function App() {
  const [kbs, setKbs] = useState<KnowledgeBase[]>([]);
  const [currentKb, setCurrentKb] = useState<KnowledgeBase | null>(null);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [sessions, setSessions] = useState<QASession[]>([]);
  const [currentSession, setCurrentSession] = useState<QASession | null>(null);
  const [messages, setMessages] = useState<QAMessage[]>([]);
  const [question, setQuestion] = useState('');
  const [streamingAnswer, setStreamingAnswer] = useState('');
  const [references, setReferences] = useState<ReferenceItem[]>([]);
  const [preview, setPreview] = useState<PreviewData | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const loadKbs = async () => {
    const data = await api.listKnowledgeBases();
    setKbs(data);
    if (!currentKb && data.length) setCurrentKb(data[0]);
  };

  useEffect(() => { loadKbs().catch(err => message.error(err.message)); }, []);

  useEffect(() => {
    if (!currentKb) return;
    Promise.all([api.listFiles(currentKb.id), api.listSessions(currentKb.id)])
      .then(([fileData, sessionData]) => {
        setFiles(fileData);
        setSessions(sessionData);
        setCurrentSession(sessionData[0] || null);
      })
      .catch(err => message.error(err.message));
  }, [currentKb?.id]);

  useEffect(() => {
    if (!currentSession) {
      setMessages([]);
      return;
    }
    api.listMessages(currentSession.id).then(setMessages).catch(err => message.error(err.message));
  }, [currentSession?.id]);

  const createKb = () => {
    Modal.confirm({
      title: '创建知识库',
      content: <Input id="new-kb-name" placeholder="知识库名称" />,
      onOk: async () => {
        const input = document.getElementById('new-kb-name') as HTMLInputElement;
        const name = input.value.trim();
        if (!name) return;
        const kb = await api.createKnowledgeBase(name);
        setKbs(prev => [kb, ...prev]);
        setCurrentKb(kb);
      }
    });
  };

  const createSession = async () => {
    if (!currentKb) return;
    const session = await api.createSession(currentKb.id);
    setSessions(prev => [session, ...prev]);
    setCurrentSession(session);
  };

  const uploadFiles = async (list: UploadFile[]) => {
    if (!currentKb) return;
    await api.uploadFiles(currentKb.id, list.map(item => item.originFileObj!).filter(Boolean) as File[]);
    setFiles(await api.listFiles(currentKb.id));
  };

  const ask = async () => {
    if (!currentSession || !question.trim()) return;
    const q = question.trim();
    setQuestion('');
    setStreamingAnswer('');
    setReferences([]);
    setMessages(prev => [...prev, {
      id: `local-${Date.now()}`,
      session_id: currentSession.id,
      knowledge_base_id: currentSession.knowledge_base_id,
      question: q,
      answer: '',
      status: 'generating',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }]);
    try {
      await api.streamQuestion(currentSession.id, q, (event, data) => {
        if (event === 'answer_delta') setStreamingAnswer(prev => prev + data.text);
        if (event === 'references') setReferences(data);
        if (event === 'error') message.error(data.message);
      });
      setMessages(await api.listMessages(currentSession.id));
    } catch (err: any) {
      message.error(err.message);
    }
  };

  const openReference = async (ref: ReferenceItem) => {
    const data = await api.getPreview(ref.id);
    setPreview(data);
    setDrawerOpen(true);
  };

  const statusColor = (status: string) => {
    if (status === 'completed') return 'success';
    if (status === 'failed') return 'error';
    if (status.includes('ing')) return 'processing';
    return 'default';
  };

  const latestAnswer = useMemo(() => streamingAnswer || messages.at(-1)?.answer || '', [streamingAnswer, messages]);

  return (
    <Layout className="app-layout">
      <Sider width={340} theme="light" className="side">
        <Flex justify="space-between" align="center">
          <Title level={4}>知识库</Title>
          <Button icon={<PlusOutlined />} onClick={createKb}>新建</Button>
        </Flex>
        <List
          dataSource={kbs}
          locale={{ emptyText: <Empty description="暂无知识库" /> }}
          renderItem={kb => (
            <List.Item className={currentKb?.id === kb.id ? 'active-row' : ''} onClick={() => setCurrentKb(kb)}>
              <Text strong>{kb.name}</Text>
            </List.Item>
          )}
        />

        <Title level={5}>文件</Title>
        <Upload beforeUpload={() => false} multiple onChange={({ fileList }) => uploadFiles(fileList)} showUploadList={false}>
          <Button icon={<FileAddOutlined />} disabled={!currentKb}>上传文件</Button>
        </Upload>
        <List
          size="small"
          dataSource={files}
          renderItem={file => (
            <List.Item actions={[
              file.status === 'failed' ? <ReloadOutlined key="retry" onClick={() => api.retryFile(file.id)} /> : null,
              <DeleteOutlined key="delete" onClick={async () => { await api.deleteFile(file.id); if (currentKb) setFiles(await api.listFiles(currentKb.id)); }} />
            ]}>
              <Space direction="vertical" size={0}>
                <Text ellipsis={{ tooltip: file.original_name }}>{file.original_name}</Text>
                <Tag color={statusColor(file.status)}>{file.status}</Tag>
                {file.error_message ? <Text type="danger">{file.error_message}</Text> : null}
              </Space>
            </List.Item>
          )}
        />

        <Title level={5}>问答会话</Title>
        <Button block icon={<PlusOutlined />} onClick={createSession} disabled={!currentKb}>新建会话</Button>
        <List
          size="small"
          dataSource={sessions}
          renderItem={session => (
            <List.Item className={currentSession?.id === session.id ? 'active-row' : ''} onClick={() => setCurrentSession(session)}>
              {session.title}
            </List.Item>
          )}
        />
      </Sider>

      <Content className="main">
        <Card className="chat-card" title={currentSession?.title || '请选择或创建会话'}>
          <div className="messages">
            {messages.map(item => (
              <Card key={item.id} size="small" className="message-card">
                <Text strong>问题：</Text><Paragraph>{item.question}</Paragraph>
                {item.answer ? <><Text strong>答案：</Text><Paragraph>{item.answer}</Paragraph></> : null}
              </Card>
            ))}
            {latestAnswer && streamingAnswer ? (
              <Card size="small" className="message-card"><Text strong>生成中：</Text><Paragraph>{latestAnswer}</Paragraph></Card>
            ) : null}
          </div>
          {references.length ? (
            <Space wrap className="refs">
              {references.map(ref => <Button size="small" key={ref.id} onClick={() => openReference(ref)}>[{ref.reference_index}] {ref.file_name || ref.chunk_type}</Button>)}
            </Space>
          ) : null}
          <Flex gap={8} className="input-row">
            <Input.TextArea rows={3} value={question} onChange={e => setQuestion(e.target.value)} placeholder="输入文字问题。第一版不支持上传图片作为问题。" />
            <Button type="primary" icon={<SendOutlined />} onClick={ask} disabled={!currentSession}>发送</Button>
          </Flex>
        </Card>
      </Content>

      <Drawer title="引用来源" open={drawerOpen} width={720} onClose={() => setDrawerOpen(false)}>
        {preview ? (
          <Space direction="vertical" className="preview" size="middle">
            {preview.asset ? <img src={preview.asset.url} className="asset-img" /> : null}
            <Card size="small" title="内容块">
              <Paragraph>{preview.chunk.content_text}</Paragraph>
              {preview.chunk.sheet_name ? <Text>工作表：{preview.chunk.sheet_name}，行：{preview.chunk.row_range}，列：{preview.chunk.col_range}</Text> : null}
            </Card>
          </Space>
        ) : <Empty />}
      </Drawer>
    </Layout>
  );
}
