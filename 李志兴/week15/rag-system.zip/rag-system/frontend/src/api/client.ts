import type { FileItem, KnowledgeBase, PreviewData, QAMessage, QASession } from '../types/api';

const API_PREFIX = '/api/v1';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_PREFIX}${path}`, {
    headers: init?.body instanceof FormData ? undefined : { 'Content-Type': 'application/json' },
    ...init
  });
  if (!res.ok) {
    let message = res.statusText;
    try {
      const err = await res.json();
      message = err.message || message;
    } catch {
      // ignore
    }
    throw new Error(message);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const api = {
  listKnowledgeBases: () => request<KnowledgeBase[]>('/knowledge-bases'),
  createKnowledgeBase: (name: string) => request<KnowledgeBase>('/knowledge-bases', { method: 'POST', body: JSON.stringify({ name }) }),
  updateKnowledgeBase: (id: string, payload: Partial<Pick<KnowledgeBase, 'name' | 'description'>>) => request<KnowledgeBase>(`/knowledge-bases/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
  deleteKnowledgeBase: (id: string) => request<void>(`/knowledge-bases/${id}`, { method: 'DELETE' }),

  listFiles: (kbId: string) => request<FileItem[]>(`/knowledge-bases/${kbId}/files`),
  uploadFiles: (kbId: string, files: File[]) => {
    const form = new FormData();
    files.forEach(file => form.append('files', file));
    return request<FileItem[]>(`/knowledge-bases/${kbId}/files`, { method: 'POST', body: form });
  },
  retryFile: (id: string) => request(`/files/${id}/retry`, { method: 'POST' }),
  deleteFile: (id: string) => request<void>(`/files/${id}`, { method: 'DELETE' }),

  listSessions: (kbId: string) => request<QASession[]>(`/knowledge-bases/${kbId}/sessions`),
  createSession: (kbId: string, title = '新会话') => request<QASession>(`/knowledge-bases/${kbId}/sessions`, { method: 'POST', body: JSON.stringify({ title }) }),
  updateSession: (id: string, title: string) => request<QASession>(`/sessions/${id}`, { method: 'PATCH', body: JSON.stringify({ title }) }),
  deleteSession: (id: string) => request<void>(`/sessions/${id}`, { method: 'DELETE' }),
  listMessages: (sessionId: string) => request<QAMessage[]>(`/sessions/${sessionId}/messages`),
  listReferences: (messageId: string) => request(`/messages/${messageId}/references`),
  getPreview: (referenceId: string) => request<PreviewData>(`/references/${referenceId}/preview`),

  streamQuestion: async (sessionId: string, question: string, onEvent: (event: string, data: any) => void) => {
    const res = await fetch(`${API_PREFIX}/sessions/${sessionId}/messages/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question })
    });
    if (!res.ok || !res.body) throw new Error('问答请求失败');
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split('\n\n');
      buffer = parts.pop() || '';
      for (const part of parts) {
        const event = part.split('\n').find(line => line.startsWith('event:'))?.replace('event:', '').trim() || 'message';
        const dataLine = part.split('\n').find(line => line.startsWith('data:'));
        if (!dataLine) continue;
        onEvent(event, JSON.parse(dataLine.replace('data:', '').trim()));
      }
    }
  }
};
