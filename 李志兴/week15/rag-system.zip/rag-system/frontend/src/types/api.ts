export interface KnowledgeBase {
  id: string;
  name: string;
  description?: string | null;
  created_at: string;
  updated_at: string;
}

export interface FileItem {
  id: string;
  knowledge_base_id: string;
  original_name: string;
  file_ext: string;
  mime_type?: string | null;
  file_size: number;
  status: string;
  error_message?: string | null;
  page_count?: number | null;
  created_at: string;
  updated_at: string;
}

export interface QASession {
  id: string;
  knowledge_base_id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface QAMessage {
  id: string;
  session_id: string;
  knowledge_base_id: string;
  question: string;
  answer?: string | null;
  status: string;
  retrieved_chunks?: unknown;
  model_config_snapshot?: unknown;
  error_message?: string | null;
  created_at: string;
  updated_at: string;
}

export interface ReferenceItem {
  id: string;
  reference_index: number;
  file_name?: string | null;
  file_id: string;
  chunk_id: string;
  chunk_type: string;
  page_number?: number | null;
  quote_text?: string | null;
  asset_id?: string | null;
}

export interface PreviewData {
  reference: Record<string, unknown>;
  chunk: {
    id: string;
    chunk_type: string;
    content_text: string;
    sheet_name?: string | null;
    row_range?: string | null;
    col_range?: string | null;
    table_id?: string | null;
  };
  asset?: {
    id: string;
    asset_type: string;
    page_number?: number | null;
    bbox?: unknown;
    url: string;
  } | null;
}
