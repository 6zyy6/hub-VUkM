#!/usr/bin/env bash
set -euo pipefail
cd backend
export APP_CONFIG_PATH=${APP_CONFIG_PATH:-../config/app.yaml}
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
