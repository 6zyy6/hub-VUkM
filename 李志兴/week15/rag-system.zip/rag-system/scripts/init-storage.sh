#!/usr/bin/env bash
set -euo pipefail
mkdir -p storage/originals storage/parsed storage/previews storage/temp
