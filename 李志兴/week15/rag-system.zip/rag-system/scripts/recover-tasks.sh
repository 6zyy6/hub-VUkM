#!/usr/bin/env bash
set -euo pipefail
python workers/app/consumers/recover_tasks.py
