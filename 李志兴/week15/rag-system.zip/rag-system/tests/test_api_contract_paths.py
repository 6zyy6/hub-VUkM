from pathlib import Path


def test_api_paths_are_declared():
    route_files = ''.join(path.read_text(encoding='utf-8') for path in Path('backend/app/api/v1/routes').glob('*.py'))
    for path in [
        '/knowledge-bases',
        '/files/{file_id}',
        '/sessions/{session_id}/messages/stream',
        '/messages/{message_id}/references',
        '/references/{reference_id}/preview',
    ]:
        assert path in route_files
