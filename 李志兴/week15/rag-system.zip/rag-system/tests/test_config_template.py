import yaml


def test_app_config_example_contains_required_sections():
    data = yaml.safe_load(open('config/app.yaml.example', encoding='utf-8'))
    for section in ['app', 'storage', 'postgres', 'kafka', 'mineru', 'milvus', 'llm', 'embedding', 'reranker', 'retrieval', 'worker']:
        assert section in data
    assert data['milvus']['collection'] == 'rag_document_chunks'
    assert data['retrieval']['top_k'] == 30
    assert data['retrieval']['top_n'] == 8
    assert data['retrieval']['max_context_chunks'] == 8
