from pathlib import Path


def test_prompts_are_externalized():
    prompt_dir = Path('config/prompts')
    assert (prompt_dir / 'rag_answer.md').exists()
    assert (prompt_dir / 'insufficient_context.md').exists()
    text = (prompt_dir / 'rag_answer.md').read_text(encoding='utf-8')
    assert '不得使用模型自身知识补全答案' in text
    assert '当前知识库中未找到足够依据' in text
