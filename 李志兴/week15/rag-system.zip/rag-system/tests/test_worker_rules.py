from pathlib import Path


def test_worker_retries_match_plan():
    text = Path('config/app.yaml.example').read_text(encoding='utf-8')
    assert 'max_retry: 3' in text
    assert 'retry_delays_seconds: [10, 30, 60]' in text


def test_worker_uses_postgres_task_state():
    pipeline = Path('workers/app/pipelines/file_pipeline.py').read_text(encoding='utf-8')
    assert 'await session.get(FileTask' in pipeline
    assert 'task.current_step' in pipeline
    assert 'retry_count' in pipeline
