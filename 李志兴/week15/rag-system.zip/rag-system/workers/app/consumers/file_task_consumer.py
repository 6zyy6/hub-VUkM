import asyncio
import json
import sys
from pathlib import Path

# backend package `app` and worker package `app` share the same directory name by design in the project plan.
# Running this file as a script lets us put backend first and worker internals second.
sys.path.insert(0, "/app/backend")
sys.path.insert(1, str(Path(__file__).resolve().parents[1]))

from aiokafka import AIOKafkaConsumer  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.core.logging import configure_logging, get_logger  # noqa: E402
from app.db.session import close_db, init_db  # noqa: E402
from pipelines.file_pipeline import FilePipeline  # noqa: E402

logger = get_logger(__name__)


async def consume() -> None:
    configure_logging()
    settings = get_settings()
    await init_db(settings.postgres.dsn)
    consumer = AIOKafkaConsumer(
        settings.kafka.file_task_topic,
        bootstrap_servers=settings.kafka.bootstrap_servers,
        group_id="rag-file-workers",
        enable_auto_commit=False,
    )
    await consumer.start()
    logger.info("file_task_consumer_started", topic=settings.kafka.file_task_topic)
    try:
        async for message in consumer:
            payload = json.loads(message.value.decode("utf-8"))
            try:
                await FilePipeline().run(payload)
                await consumer.commit()
            except Exception as exc:
                logger.exception("file_task_processing_failed", error=str(exc), payload=payload)
                await consumer.commit()
    finally:
        await consumer.stop()
        await close_db()


if __name__ == "__main__":
    asyncio.run(consume())
