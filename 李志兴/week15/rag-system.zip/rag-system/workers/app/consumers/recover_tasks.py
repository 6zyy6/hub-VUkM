import asyncio
import sys
import uuid
from pathlib import Path

sys.path.insert(0, "/app/backend")

from sqlalchemy import select  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.db.session import SessionLocal, close_db, init_db  # noqa: E402
from app.integrations.kafka_client import KafkaProducerClient  # noqa: E402
from app.models.entities import FileTask  # noqa: E402
from app.models.enums import TaskStatus  # noqa: E402


async def recover() -> None:
    settings = get_settings()
    await init_db(settings.postgres.dsn)
    assert SessionLocal is not None
    async with SessionLocal() as session:
        tasks = (await session.scalars(select(FileTask).where(FileTask.status.in_([TaskStatus.pending.value, TaskStatus.running.value, TaskStatus.retrying.value])))).all()
        async with KafkaProducerClient(settings.kafka) as producer:
            for task in tasks:
                task.status = TaskStatus.pending.value
                task.retry_count = 0
                await producer.send_file_task({
                    "trace_id": str(uuid.uuid4()),
                    "task_id": str(task.id),
                    "file_id": str(task.file_id),
                    "knowledge_base_id": str(task.knowledge_base_id),
                    "step": task.current_step,
                })
        await session.commit()
    await close_db()


if __name__ == "__main__":
    asyncio.run(recover())
