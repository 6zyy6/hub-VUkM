import asyncio
import json
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sqlalchemy import select

from app.core.config import get_settings
from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.integrations.embedding_client import EmbeddingClient
from app.integrations.kafka_client import KafkaProducerClient
from app.integrations.milvus_client import MilvusClient
from app.integrations.mineru_client import MinerUClient
from app.models.entities import DocumentChunk, File, FileTask
from app.models.enums import FileStatus, TaskStatus, TaskStep
from services.chunker import StructureFirstChunker
from services.mineru_result_adapter import MinerUResultAdapter
from services.preview_service import PreviewService

logger = get_logger(__name__)


class FilePipeline:
    def __init__(self):
        self.settings = get_settings()

    async def run(self, payload: dict) -> None:
        assert SessionLocal is not None
        async with SessionLocal() as session:
            task = await session.get(FileTask, uuid.UUID(payload["task_id"]))
            if not task:
                logger.warning("task_not_found", payload=payload)
                return
            file = await session.get(File, task.file_id)
            if not file:
                logger.warning("file_not_found", task_id=str(task.id))
                return
            try:
                task.status = TaskStatus.running.value
                task.started_at = task.started_at or datetime.now(timezone.utc)
                await session.commit()
                await self._execute_steps(session, task, file)
                task.status = TaskStatus.completed.value
                task.current_step = TaskStep.completed.value
                task.finished_at = datetime.now(timezone.utc)
                file.status = FileStatus.completed.value
                await session.commit()
            except Exception as exc:
                await self._handle_failure(session, task, file, exc, payload)

    async def _execute_steps(self, session, task: FileTask, file: File) -> None:
        if task.current_step in {TaskStep.pending_parse.value, TaskStep.parsing.value}:
            await self._parse(session, task, file)
        if task.current_step == TaskStep.chunking.value:
            await self._chunk(session, task, file)
        if task.current_step == TaskStep.previewing.value:
            await self._preview(session, task, file)
        if task.current_step == TaskStep.embedding.value:
            await self._embedding_and_index(session, task, file)

    async def _parse(self, session, task: FileTask, file: File) -> None:
        task.current_step = TaskStep.parsing.value
        file.status = FileStatus.parsing.value
        await session.commit()
        parsed_dir = Path(file.parsed_dir or self.settings.storage.parsed_dir) / str(file.id)
        result = await MinerUClient(self.settings.mineru).parse_file(Path(file.original_path), parsed_dir)
        parsed_dir.mkdir(parents=True, exist_ok=True)
        (parsed_dir / "mineru_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        file.parsed_dir = str(parsed_dir)
        file.page_count = result.get("page_count") or result.get("pages_count")
        task.current_step = TaskStep.chunking.value
        file.status = FileStatus.chunking.value
        await session.commit()

    async def _chunk(self, session, task: FileTask, file: File) -> None:
        path = Path(file.parsed_dir or "") / "mineru_result.json"
        result = json.loads(path.read_text(encoding="utf-8"))
        blocks = MinerUResultAdapter().adapt(result)
        split_blocks = StructureFirstChunker(max_tokens=1200, overlap_tokens=100).split(blocks)
        existing = (await session.scalars(select(DocumentChunk).where(DocumentChunk.file_id == file.id))).all()
        for item in existing:
            await session.delete(item)
        await session.flush()
        chunks: list[DocumentChunk] = []
        for idx, block in enumerate(split_blocks, start=1):
            chunk = DocumentChunk(
                knowledge_base_id=file.knowledge_base_id,
                file_id=file.id,
                chunk_index=idx,
                chunk_type=block.chunk_type,
                title_path=block.title_path,
                content_text=block.text,
                content_summary=block.text[:300],
                page_number=block.page_number,
                bbox=block.bbox,
                sheet_name=block.sheet_name,
                row_range=block.row_range,
                col_range=block.col_range,
                table_id=block.table_id,
                metadata_=block.metadata,
            )
            session.add(chunk)
            chunks.append(chunk)
        await session.flush()
        task.current_step = TaskStep.previewing.value
        file.status = FileStatus.indexing.value
        await session.commit()

    async def _preview(self, session, task: FileTask, file: File) -> None:
        chunks = list((await session.scalars(select(DocumentChunk).where(DocumentChunk.file_id == file.id).order_by(DocumentChunk.chunk_index))).all())
        assets = PreviewService().create_assets(file, chunks)
        for asset in assets:
            session.add(asset)
        task.current_step = TaskStep.embedding.value
        file.status = FileStatus.embedding.value
        await session.commit()

    async def _embedding_and_index(self, session, task: FileTask, file: File) -> None:
        chunks = list((await session.scalars(select(DocumentChunk).where(DocumentChunk.file_id == file.id).order_by(DocumentChunk.chunk_index))).all())
        client = EmbeddingClient(self.settings.embedding)
        milvus_rows = []
        now = int(time.time())
        for start in range(0, len(chunks), self.settings.embedding.batch_size):
            batch = chunks[start:start + self.settings.embedding.batch_size]
            vectors = await client.embed([chunk.content_text for chunk in batch])
            for chunk, vector in zip(batch, vectors):
                vector_id = str(uuid.uuid4())
                chunk.milvus_vector_id = vector_id
                milvus_rows.append({
                    "id": vector_id,
                    "chunk_id": str(chunk.id),
                    "knowledge_base_id": str(chunk.knowledge_base_id),
                    "file_id": str(chunk.file_id),
                    "chunk_type": chunk.chunk_type,
                    "page_number": chunk.page_number or 0,
                    "created_at": now,
                    "embedding": vector,
                })
        MilvusClient(self.settings.milvus).upsert_vectors(milvus_rows)
        task.current_step = TaskStep.completed.value
        file.status = FileStatus.completed.value
        await session.commit()

    async def _handle_failure(self, session, task: FileTask, file: File, exc: Exception, payload: dict) -> None:
        task.retry_count += 1
        task.error_code = self._error_code_for_step(task.current_step)
        task.error_message = str(exc)
        file.error_message = str(exc)
        if task.retry_count <= task.max_retry:
            delay = self.settings.worker.retry_delays_seconds[min(task.retry_count - 1, len(self.settings.worker.retry_delays_seconds) - 1)]
            task.status = TaskStatus.retrying.value
            task.next_retry_at = datetime.now(timezone.utc) + timedelta(seconds=delay)
            await session.commit()
            await asyncio.sleep(delay)
            async with KafkaProducerClient(self.settings.kafka) as producer:
                payload["step"] = task.current_step
                await producer.send_file_task(payload)
        else:
            task.status = TaskStatus.failed.value
            file.status = FileStatus.failed.value
            task.finished_at = datetime.now(timezone.utc)
            await session.commit()
            async with KafkaProducerClient(self.settings.kafka) as producer:
                await producer.send_failed_task({**payload, "error_code": task.error_code, "error_message": task.error_message})

    @staticmethod
    def _error_code_for_step(step: str) -> str:
        return {
            TaskStep.parsing.value: "MINERU_PARSE_FAILED",
            TaskStep.chunking.value: "TASK_CHUNKING_FAILED",
            TaskStep.previewing.value: "TASK_PREVIEW_FAILED",
            TaskStep.embedding.value: "EMBEDDING_FAILED",
            TaskStep.indexing.value: "MILVUS_INDEX_FAILED",
        }.get(step, "TASK_FAILED")
