from services.mineru_result_adapter import ParsedBlock


class StructureFirstChunker:
    def __init__(self, max_tokens: int = 1200, overlap_tokens: int = 100):
        self.max_tokens = max_tokens
        self.overlap_tokens = overlap_tokens

    def split(self, blocks: list[ParsedBlock]) -> list[ParsedBlock]:
        chunks: list[ParsedBlock] = []
        for block in blocks:
            if block.chunk_type == "table":
                chunks.extend(self._split_table(block))
            elif self._approx_tokens(block.text) > self.max_tokens:
                chunks.extend(self._split_long_text(block))
            else:
                chunks.append(block)
        return chunks

    def _split_table(self, block: ParsedBlock) -> list[ParsedBlock]:
        rows = block.text.splitlines()
        if len(rows) <= 50:
            return [block]
        header = rows[0]
        chunks = []
        for start in range(1, len(rows), 50):
            part_rows = [header] + rows[start:start + 50]
            new = ParsedBlock(**{**block.__dict__})
            new.text = "\n".join(part_rows)
            new.row_range = f"{start + 1}-{min(start + 50, len(rows))}"
            chunks.append(new)
        return chunks

    def _split_long_text(self, block: ParsedBlock) -> list[ParsedBlock]:
        words = block.text.split()
        step = max(self.max_tokens - self.overlap_tokens, 1)
        chunks = []
        for start in range(0, len(words), step):
            new = ParsedBlock(**{**block.__dict__})
            new.text = " ".join(words[start:start + self.max_tokens])
            chunks.append(new)
            if start + self.max_tokens >= len(words):
                break
        return chunks

    @staticmethod
    def _approx_tokens(text: str) -> int:
        # 粗略估算，不引入 tokenizer 以避免绑定具体模型实现。
        return max(len(text) // 4, len(text.split()))
