from dataclasses import dataclass, field
from typing import Any


@dataclass
class ParsedBlock:
    chunk_type: str
    text: str
    page_number: int | None = None
    bbox: dict | None = None
    title_path: list[str] = field(default_factory=list)
    sheet_name: str | None = None
    row_range: str | None = None
    col_range: str | None = None
    table_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class MinerUResultAdapter:
    """把 MinerU 结构化解析结果转成系统内部切分输入。

    MinerU 不同部署形态的 JSON 字段可能有差异，因此这里只依赖最常见的结构字段，
    并保留原始 block 到 metadata，避免业务流程绑定某个非方案内的私有格式。
    """

    def adapt(self, result: dict[str, Any]) -> list[ParsedBlock]:
        blocks: list[ParsedBlock] = []
        candidates = result.get("blocks") or result.get("content") or result.get("pages") or []
        if isinstance(candidates, dict):
            candidates = candidates.get("blocks") or candidates.get("items") or []
        for item in candidates:
            if "blocks" in item and isinstance(item["blocks"], list):
                for child in item["blocks"]:
                    blocks.extend(self._from_item(child, page_number=item.get("page_number") or item.get("page")))
            else:
                blocks.extend(self._from_item(item))
        return [block for block in blocks if block.text.strip()]

    def _from_item(self, item: dict[str, Any], page_number: int | None = None) -> list[ParsedBlock]:
        item_type = str(item.get("type") or item.get("category") or "text").lower()
        text = item.get("text") or item.get("content") or item.get("markdown") or ""
        page = item.get("page_number") or item.get("page") or page_number
        bbox = item.get("bbox") or item.get("position")
        title_path = item.get("title_path") or item.get("headings") or []
        if isinstance(title_path, str):
            title_path = [title_path]
        if "table" in item_type:
            return [ParsedBlock(
                chunk_type="table",
                text=str(text),
                page_number=page,
                bbox=bbox,
                title_path=title_path,
                sheet_name=item.get("sheet_name"),
                row_range=item.get("row_range"),
                col_range=item.get("col_range"),
                table_id=item.get("table_id") or item.get("id"),
                metadata={"source_block": item},
            )]
        if "image" in item_type or "figure" in item_type:
            image_text = "\n".join(str(v) for v in [item.get("caption"), item.get("ocr_text"), text] if v)
            return [ParsedBlock(
                chunk_type="image",
                text=image_text,
                page_number=page,
                bbox=bbox,
                title_path=title_path,
                metadata={"source_block": item, "image_path": item.get("image_path") or item.get("path")},
            )]
        return [ParsedBlock(
            chunk_type="text",
            text=str(text),
            page_number=page,
            bbox=bbox,
            title_path=title_path,
            metadata={"source_block": item},
        )]
