from pathlib import Path

from pdf2image import convert_from_path
from PIL import Image

from app.models.entities import ChunkAsset, DocumentChunk, File
from app.models.enums import AssetType


class PreviewService:
    def create_assets(self, file: File, chunks: list[DocumentChunk]) -> list[ChunkAsset]:
        ext = file.file_ext.lower()
        if ext == ".pdf":
            return self._pdf_assets(file, chunks)
        if ext in {".png", ".jpg", ".jpeg", ".webp"}:
            return self._image_assets(file, chunks)
        return []

    def _pdf_assets(self, file: File, chunks: list[DocumentChunk]) -> list[ChunkAsset]:
        preview_dir = Path(file.preview_dir or "")
        preview_dir.mkdir(parents=True, exist_ok=True)
        assets: list[ChunkAsset] = []
        try:
            pages = convert_from_path(file.original_path, fmt="png")
        except Exception:
            pages = []
        page_paths: dict[int, Path] = {}
        for idx, page in enumerate(pages, start=1):
            path = preview_dir / f"page-{idx}.png"
            page.save(path)
            page_paths[idx] = path
        for chunk in chunks:
            if not chunk.page_number or chunk.page_number not in page_paths:
                continue
            page_path = page_paths[chunk.page_number]
            assets.append(ChunkAsset(
                chunk_id=chunk.id,
                file_id=file.id,
                asset_type=AssetType.pdf_page_preview.value,
                asset_path=str(page_path),
                page_number=chunk.page_number,
                bbox=chunk.bbox,
                metadata_={},
            ))
            if chunk.chunk_type in {"image", "formula", "layout"} and chunk.bbox:
                crop_path = self._crop_pdf_region(page_path, preview_dir, chunk)
                if crop_path:
                    assets.append(ChunkAsset(
                        chunk_id=chunk.id,
                        file_id=file.id,
                        asset_type=AssetType.pdf_crop.value,
                        asset_path=str(crop_path),
                        page_number=chunk.page_number,
                        bbox=chunk.bbox,
                        metadata_={},
                    ))
        return assets

    def _crop_pdf_region(self, page_path: Path, preview_dir: Path, chunk: DocumentChunk) -> Path | None:
        try:
            bbox = chunk.bbox or {}
            x1, y1, x2, y2 = [int(bbox[k]) for k in ("x1", "y1", "x2", "y2")]
            with Image.open(page_path) as img:
                width, height = img.size
                if x1 < 0 or y1 < 0 or x2 <= x1 or y2 <= y1 or x2 > width or y2 > height:
                    return None
                crop = img.crop((x1, y1, x2, y2))
                target = preview_dir / f"chunk-{chunk.id}-crop.png"
                crop.save(target)
                return target
        except Exception:
            return None

    def _image_assets(self, file: File, chunks: list[DocumentChunk]) -> list[ChunkAsset]:
        assets: list[ChunkAsset] = []
        for chunk in chunks:
            assets.append(ChunkAsset(
                chunk_id=chunk.id,
                file_id=file.id,
                asset_type=AssetType.image_original.value,
                asset_path=file.original_path,
                page_number=None,
                bbox=None,
                metadata_={},
            ))
        return assets
