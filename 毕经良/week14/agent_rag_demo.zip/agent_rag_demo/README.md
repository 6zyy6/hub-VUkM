# LangChain RAG 知识库问答系统

基于 LangChain 框架开发的本地知识库问答系统，支持文档检索 + LLM 回答的 RAG 流程。

## 项目结构

```
/Users/jlbi/Desktop/作业/
├── config.yaml          # 配置文件
├── main.py              # FastAPI 服务入口
├── agent.py             # LangChain RAG 链核心
├── db.py                # SQLite 数据库模型
├── document_processor.py # PDF 文档处理
├── config.yaml          # 配置 (LLM/Embedding)
├── requirements.txt     # 依赖
└── chroma_db/           # 向量数据库目录
```

## 核心架构

```
用户提问
    │
    ▼
┌────────────────────────────────────────┐
│         LangChain RAG Chain             │
│                                        │
│  1. retrieve_fn (RunnableLambda)        │
│     ↓ 向量检索                          │
│  2. PromptTemplate                      │
│     ↓ 拼接上下文                        │
│  3. ChatOpenAI (通义千问)                │
│     ↓ LLM 生成                          │
│  4. StrOutputParser                     │
└────────────────────────────────────────┘
                    │
                    ▼
               返回回答
```

## LangChain 组件

| 组件 | 用途 |
|------|------|
| `ChatOpenAI` | LLM 调用 (通义千问) |
| `HuggingFaceBgeEmbeddings` | BGE Embedding 模型 |
| `Chroma` | 向量存储 |
| `PromptTemplate` | 提示词模板 |
| `RunnableLambda` | 自定义检索函数 |
| `RunnablePassthrough` | 管道传递 |
| `StrOutputParser` | 输出解析 |

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置

编辑 `config.yaml`:

```yaml
rag:
  llm_base: "https://dashscope.aliyuncs.com/compatible-mode/v1"
  llm_api_key: "your-api-key"      # 阿里云 DashScope API Key
  llm_model: "qwen-plus"           # 模型
  embedding_path: "/path/to/bge-model/"  # BGE 模型路径
  chunk_size: 256
  chunk_overlap: 20
  top_k: 5
  port: 8000
```

### 3. 启动服务

```bash
python main.py
```

服务运行在 `http://localhost:8000`

---

## API 接口

### 健康检查

```bash
curl http://localhost:8000/health
```

### 知识库管理

#### 创建知识库

```bash
curl -X POST "http://localhost:8000/knowledge_base" \
  -F "name=我的知识库" \
  -F "description=测试知识库"
```

**响应示例：**
```json
{
  "request_id": "6a311ad4-b623-4883-af41-d49d1efa00f9",
  "knowledge_id": 1,
  "name": "我的知识库",
  "description": "测试知识库",
  "response_code": 200,
  "response_msg": "创建成功"
}
```

#### 列出所有知识库

```bash
curl http://localhost:8000/knowledge_bases
```

**响应示例：**
```json
{
  "request_id": "c8195f09-3db5-43c3-a988-072b804d0c3e",
  "data": [
    {
      "knowledge_id": 1,
      "name": "我的知识库",
      "description": "测试知识库",
      "created_at": "2026-05-15T12:27:07.135626"
    }
  ],
  "response_code": 200,
  "response_msg": "查询成功"
}
```

#### 获取知识库信息

```bash
curl http://localhost:8000/knowledge_base/1
```

#### 删除知识库

```bash
curl -X DELETE "http://localhost:8000/knowledge_base/1"
```

---

### 文档管理

#### 上传文档
```bash
curl -X POST "http://localhost:8000/document/upload" \
  -F "knowledge_id=1" \
  -F "title=测试文档" \
  -F "file=@/path/to/document.pdf"
```

**响应示例：**
```json
{
  "request_id": "...",
  "document_id": 1,
  "knowledge_id": 1,
  "title": "测试文档",
  "file_type": "application/pdf",
  "response_code": 200,
  "response_msg": "上传并索引成功"
}
```

#### 获取文档信息

```bash
curl http://localhost:8000/document/1
```

#### 删除文档

```bash
curl -X DELETE "http://localhost:8000/document/1"
```

---

### RAG 问答

#### 提问

```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"knowledge_id": 1, "message": "文档里讲了什么？"}'
```

**响应示例：**
```json
{
  "request_id": "...",
  "knowledge_id": 1,
  "message": "根据知识库中的资料，文档主要讲述了...",
  "response_code": 200,
  "response_msg": "回答成功"
}
```

---

## 完整使用流程

### 1. 创建知识库

```bash
curl -X POST "http://localhost:8000/knowledge_base" \
  -F "name=AI知识库" \
  -F "description=AI相关知识"
```

### 2. 上传文档

```bash
curl -X POST "http://localhost:8000/document/upload" \
  -F "knowledge_id=1" \
  -F "title=LangChain文档" \
  -F "file=@/Users/jlbi/Documents/langchain.pdf"
```

### 3. 提问

```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"knowledge_id": 1, "message": "什么是 LangChain？"}'
```

---

## 工作流程

```
1. 用户上传 PDF 文档
         ↓
2. document_processor.py 提取文本内容
         ↓
3. 文本分块 (chunk_text)
         ↓
4. Chroma 向量存储 (add_documents)
         ↓
5. 用户提问
         ↓
6. RAG Chain 处理:
   - retrieve_fn 向量检索
   - 拼接提示词
   - LLM 生成回答
         ↓
7. 返回回答
```

---

## 错误码说明

| response_code | 说明 |
|----------------|------|
| 200 | 成功 |
| 404 | 资源不存在 |
| 500 | 服务器错误 |

---

## 依赖

- fastapi
- uvicorn
- pydantic
- sqlalchemy
- langchain >= 1.0
- langchain-core
- langchain-openai
- langchain-community
- chromadb
- sentence-transformers
- huggingface-hub
- pdfplumber
- pyyaml