"""
LangChain Agent 智能体 - 基于工具调用的问答系统
使用 LCEL 风格的手动工具调用
"""
import yaml
import os
from typing import List, Dict, Optional, Any, Union

from langchain_core.prompts import PromptTemplate, ChatPromptTemplate
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage, ToolMessage
from langchain_core.tools import tool, StructuredTool
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceBgeEmbeddings
from langchain_openai import ChatOpenAI

from document_processor import chunk_text

# 加载配置
config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

# 配置读取
LLM_BASE = config["rag"]["llm_base"]
LLM_API_KEY = config["rag"]["llm_api_key"]
LLM_MODEL = config["rag"]["llm_model"]
EMBEDDING_PATH = config["rag"]["embedding_path"]
CHUNK_SIZE = config["rag"]["chunk_size"]
CHUNK_OVERLAP = config["rag"]["chunk_overlap"]
TOP_K = config["rag"]["top_k"]

PERSIST_DIR = os.path.join(os.path.dirname(__file__), "chroma_db")


# ==================== 工具定义 ====================

class KnowledgeBaseTool:
    """知识库工具封装"""

    def __init__(self, knowledge_id: int = 1):
        self.knowledge_id = knowledge_id
        self.embeddings = HuggingFaceBgeEmbeddings(
            model_name=EMBEDDING_PATH,
            model_kwargs={"device": "cpu"},
            encode_kwargs={"normalize_embeddings": True}
        )
        self.vectorstore = Chroma(
            collection_name=f"kb_{knowledge_id}",
            embedding_function=self.embeddings,
            persist_directory=PERSIST_DIR
        )

    def search(self, query: str, top_k: int = 5) -> str:
        """搜索知识库相关文档"""
        docs = self.vectorstore.similarity_search(query, k=top_k)
        if not docs:
            return "知识库中没有找到相关内容。"

        result = "找到以下相关内容：\n\n"
        for i, doc in enumerate(docs):
            result += f"[文档 {i+1}]\n{doc.page_content}\n\n"
        return result

    def index_document(self, document_id: int, title: str, content: str, file_path: str = ""):
        """索引文档到知识库"""
        from langchain_core.documents import Document

        chunks = chunk_text(content, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP)
        documents = [
            Document(
                page_content=chunk,
                metadata={
                    "document_id": document_id,
                    "knowledge_id": self.knowledge_id,
                    "title": title,
                    "file_path": file_path,
                    "chunk_index": i
                }
            )
            for i, chunk in enumerate(chunks)
        ]
        self.vectorstore.add_documents(documents)


# 创建全局知识库工具实例
_kb_tools: Dict[int, KnowledgeBaseTool] = {}


def get_kb_tool(knowledge_id: int = 1) -> KnowledgeBaseTool:
    global _kb_tools
    if knowledge_id not in _kb_tools:
        _kb_tools[knowledge_id] = KnowledgeBaseTool(knowledge_id)
    return _kb_tools[knowledge_id]


def search_knowledge_base_func(query: str, knowledge_id: int = 1) -> str:
    """搜索知识库获取相关信息"""
    tool = get_kb_tool(knowledge_id)
    return tool.search(query, TOP_K)


def index_document_to_kb_func(document_id: int, title: str, content: str, knowledge_id: int = 1) -> str:
    """将文档内容索引到知识库"""
    tool = get_kb_tool(knowledge_id)
    tool.index_document(document_id, title, content)
    return f"文档 '{title}' 已成功索引到知识库"


# ==================== Agent 定义 ====================

class QAAgent:
    """
    基于 LangChain 的 RAG 问答智能体

    使用 LCEL 风格的工具调用，而非依赖 create_agent
    """

    def __init__(self, knowledge_id: int = 1):
        self.knowledge_id = knowledge_id

        # 初始化 LLM
        self.llm = ChatOpenAI(
            model=LLM_MODEL,
            api_key=LLM_API_KEY,
            base_url=LLM_BASE,
            temperature=0.7
        )

        # 构建 RAG Chain
        self._build_chain()

    def _build_chain(self):
        """构建 RAG Chain"""
        from langchain_core.documents import Document

        # 1. 检索工具 (作为 Runnable)
        def retrieve(query: str) -> str:
            tool = get_kb_tool(self.knowledge_id)
            return tool.search(query, TOP_K)

        retrieve_fn = RunnableLambda(retrieve)

        # 2. 提示词模板
        template = """你是一个专业的问答助手，擅长根据知识库中的资料回答用户问题。

请根据以下参考资料回答用户的问题。如果资料中没有相关信息，请直接说明"从知识库中没有获取到相应的信息"，不要编造答案。

参考资料：
{context}

用户问题：{question}

回答：
"""
        PROMPT = PromptTemplate.from_template(template)

        # 3. RAG Chain: 检索 -> 生成
        self.chain = (
            {"context": retrieve_fn, "question": RunnablePassthrough()}
            | PROMPT
            | self.llm
            | StrOutputParser()
        )

    def chat(self, query: str) -> str:
        """
        与智能体对话

        Args:
            query: 用户问题

        Returns:
            智能体回答
        """
        try:
            result = self.chain.invoke(query)
            return result
        except Exception as e:
            import traceback
            traceback.print_exc()
            return f"Error: {str(e)}"


# 全局 Agent 实例
_agents: Dict[int, QAAgent] = {}


def get_agent(knowledge_id: int = 1) -> QAAgent:
    """获取指定知识库的智能体"""
    global _agents
    if knowledge_id not in _agents:
        _agents[knowledge_id] = QAAgent(knowledge_id)
    return _agents[knowledge_id]