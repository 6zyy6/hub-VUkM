"""
文档处理工具 - PDF 文本提取
"""
import pdfplumber
from typing import List, Dict


def extract_pdf_text(file_path: str) -> List[Dict[str, any]]:
    """
    从 PDF 文件中提取文本内容

    Args:
        file_path: PDF 文件路径

    Returns:
        List of dicts with 'page' and 'text' keys
    """
    pages_content = []

    try:
        with pdfplumber.open(file_path) as pdf:
            for page_num, page in enumerate(pdf.pages):
                text = page.extract_text()
                if text:
                    pages_content.append({
                        "page": page_num + 1,
                        "text": text.strip()
                    })
    except Exception as e:
        print(f"Error extracting PDF: {e}")

    return pages_content


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    """
    将文本分块

    Args:
        text: 待分块文本
        chunk_size: 块大小（字符数）
        overlap: 重叠字符数

    Returns:
        文本块列表
    """
    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = start + chunk_size - overlap

    return chunks