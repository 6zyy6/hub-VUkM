"""
Embedding 模型封装
"""
import numpy as np
from sentence_transformers import SentenceTransformer
import yaml
import os

# 加载配置
config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

EMBEDDING_MODEL_PATH = config["rag"]["embedding_path"]
EMBEDDING_DIMS = config["rag"]["embedding_dims"]


class EmbeddingModel:
    """Embedding 模型封装"""

    def __init__(self):
        self.model = SentenceTransformer(EMBEDDING_MODEL_PATH)
        self.dims = EMBEDDING_DIMS

    def encode(self, texts: list[str] | str) -> np.ndarray:
        """
        将文本转换为向量

        Args:
            texts: 单个文本或文本列表

        Returns:
            numpy array of embeddings
        """
        if isinstance(texts, str):
            texts = [texts]

        embeddings = self.model.encode(texts, normalize_embeddings=True)
        return embeddings

    def similarity(self, text1: str, text2: str) -> float:
        """计算两个文本的相似度"""
        emb1 = self.encode(text1)
        emb2 = self.encode(text2)
        return float(np.dot(emb1, emb2))


# 全局单例
embedding_model = None


def get_embedding_model() -> EmbeddingModel:
    global embedding_model
    if embedding_model is None:
        embedding_model = EmbeddingModel()
    return embedding_model