"""
LangChain Agent 示例 - 演示智能体问答能力
"""
from agent import get_agent, QAAgent, index_document_to_kb, get_kb_tool


def chat_example():
    """问答示例"""
    print("=" * 60)
    print("LangChain Agent 问答示例")
    print("=" * 60)

    # 获取 Agent（会自动使用 ReAct 推理）
    agent = get_agent(knowledge_id=1)

    # 提问
    questions = [
        "什么是机器学习？",
        "如何学习深度学习？",
        "RAG 是什么？"
    ]

    for q in questions:
        print(f"\n用户问题: {q}")
        print("-" * 40)

        # Agent 会自动：
        # 1. 思考是否需要搜索知识库
        # 2. 调用 search_knowledge_base 工具
        # 3. 基于搜索结果生成回答
        answer = agent.chat(q)
        print(f"Agent 回答: {answer}")
        print()


def tool_demo():
    """工具使用示例"""
    print("\n" + "=" * 60)
    print("Agent 工具使用示例")
    print("=" * 60)

    # 直接使用工具
    kb_tool = get_kb_tool(knowledge_id=1)

    # 搜索知识库
    result = kb_tool.search("机器学习")
    print("搜索结果:", result[:200], "...")

    # 索引文档
    result = index_document_to_kb.invoke({
        "document_id": 999,
        "title": "测试文档",
        "content": "这是测试文档的内容。",
        "knowledge_id": 1
    })
    print("索引结果:", result)


def agent_workflow():
    """Agent 工作流程演示"""
    print("\n" + "=" * 60)
    print("ReAct Agent 工作流程")
    print("=" * 60)
    print("""
LangChain Agent 采用 ReAct 推理模式：

Thought: 思考需要做什么
Action: 执行工具调用
Observation: 观察结果
Final Answer: 生成最终回答

示例流程：
1. 用户问: "什么是 RAG？"
2. Agent Thought: 我需要搜索知识库获取相关信息
3. Agent Action: search_knowledge_base(query="RAG", knowledge_id=1)
4. Agent Observation: 找到相关文档内容...
5. Agent Final Answer: 根据搜索结果回答问题
    """)


if __name__ == "__main__":
    print("LangChain Agent 智能体演示")
    print("请确保服务已启动并已上传文档到知识库")
    print()

    # 工具演示（不需要服务运行）
    tool_demo()

    # Agent 问答（需要服务运行）
    # chat_example()

    # 工作流程说明
    agent_workflow()