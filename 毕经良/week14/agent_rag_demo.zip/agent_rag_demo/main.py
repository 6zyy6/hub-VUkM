"""
FastAPI 服务 - 基于 LangChain Agent 的知识库问答系统
"""
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import uuid
import os
import yaml

from db import init_db, get_session, KnowledgeBase, Document
from agent import get_agent, QAAgent, get_kb_tool
from document_processor import extract_pdf_text

# 加载配置
config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

app = FastAPI(title="LangChain Agent 知识库问答系统", version="1.0.0")

# 确保上传目录存在
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ============== 响应模型 ==============

class KnowledgeBaseResponse(BaseModel):
    request_id: str
    knowledge_id: int
    name: str
    description: str
    response_code: int
    response_msg: str


class DocumentResponse(BaseModel):
    request_id: str
    document_id: int
    knowledge_id: int
    title: str
    file_type: str
    response_code: int
    response_msg: str


class ChatRequest(BaseModel):
    knowledge_id: int
    message: str


class ChatResponse(BaseModel):
    request_id: str
    knowledge_id: int
    message: str
    response_code: int
    response_msg: str


# ============== 知识库管理 ==============

@app.get("/knowledge_base/{knowledge_id}", response_model=KnowledgeBaseResponse)
def get_knowledge_base(knowledge_id: int):
    """获取知识库信息"""
    session = get_session()
    try:
        kb = session.query(KnowledgeBase).filter(KnowledgeBase.id == knowledge_id).first()
        if not kb:
            return KnowledgeBaseResponse(
                request_id=str(uuid.uuid4()),
                knowledge_id=0,
                name="",
                description="",
                response_code=404,
                response_msg="知识库不存在"
            )

        return KnowledgeBaseResponse(
            request_id=str(uuid.uuid4()),
            knowledge_id=kb.id,
            name=kb.name,
            description=kb.description,
            response_code=200,
            response_msg="查询成功"
        )
    finally:
        session.close()


@app.post("/knowledge_base", response_model=KnowledgeBaseResponse)
def create_knowledge_base(name: str = Form(...), description: str = Form("")):
    """创建知识库"""
    session = get_session()
    try:
        kb = KnowledgeBase(name=name, description=description)
        session.add(kb)
        session.commit()

        return KnowledgeBaseResponse(
            request_id=str(uuid.uuid4()),
            knowledge_id=kb.id,
            name=kb.name,
            description=kb.description,
            response_code=200,
            response_msg="创建成功"
        )
    finally:
        session.close()


@app.delete("/knowledge_base/{knowledge_id}", response_model=KnowledgeBaseResponse)
def delete_knowledge_base(knowledge_id: int):
    """删除知识库"""
    session = get_session()
    try:
        kb = session.query(KnowledgeBase).filter(KnowledgeBase.id == knowledge_id).first()
        if not kb:
            return KnowledgeBaseResponse(
                request_id=str(uuid.uuid4()),
                knowledge_id=0,
                name="",
                description="",
                response_code=404,
                response_msg="知识库不存在"
            )

        docs = session.query(Document).filter(Document.knowledge_id == knowledge_id).all()
        for doc in docs:
            session.delete(doc)

        session.delete(kb)
        session.commit()

        return KnowledgeBaseResponse(
            request_id=str(uuid.uuid4()),
            knowledge_id=knowledge_id,
            name=kb.name,
            description=kb.description,
            response_code=200,
            response_msg="删除成功"
        )
    finally:
        session.close()


@app.get("/knowledge_bases")
def list_knowledge_bases():
    """列出所有知识库"""
    session = get_session()
    try:
        kbs = session.query(KnowledgeBase).all()
        return {
            "request_id": str(uuid.uuid4()),
            "data": [
                {
                    "knowledge_id": kb.id,
                    "name": kb.name,
                    "description": kb.description,
                    "created_at": kb.created_at.isoformat()
                }
                for kb in kbs
            ],
            "response_code": 200,
            "response_msg": "查询成功"
        }
    finally:
        session.close()


# ============== 文档管理 ==============

@app.get("/document/{document_id}", response_model=DocumentResponse)
def get_document(document_id: int):
    """获取文档信息"""
    session = get_session()
    try:
        doc = session.query(Document).filter(Document.id == document_id).first()
        if not doc:
            return DocumentResponse(
                request_id=str(uuid.uuid4()),
                document_id=0,
                knowledge_id=0,
                title="",
                file_type="",
                response_code=404,
                response_msg="文档不存在"
            )

        return DocumentResponse(
            request_id=str(uuid.uuid4()),
            document_id=doc.id,
            knowledge_id=doc.knowledge_id,
            title=doc.title,
            file_type=doc.file_type or "",
            response_code=200,
            response_msg="查询成功"
        )
    finally:
        session.close()


@app.post("/document/upload", response_model=DocumentResponse)
async def upload_document(
    knowledge_id: int = Form(...),
    title: str = Form(...),
    file: UploadFile = File(...)
):
    """上传文档（使用 Agent 自动建立索引）"""
    session = get_session()
    try:
        kb = session.query(KnowledgeBase).filter(KnowledgeBase.id == knowledge_id).first()
        if not kb:
            return DocumentResponse(
                request_id=str(uuid.uuid4()),
                document_id=0,
                knowledge_id=0,
                title="",
                file_type="",
                response_code=404,
                response_msg="知识库不存在"
            )

        # 保存文件
        file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}_{file.filename}")
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)

        # 提取文档内容
        file_type = file.content_type or ""
        content = ""

        if "pdf" in file_type:
            pages = extract_pdf_text(file_path)
            content = "\n\n".join([f"[第{p['page']}页]\n{p['text']}" for p in pages])

        # 创建文档记录
        doc = Document(
            knowledge_id=knowledge_id,
            title=title,
            content=content,
            file_path=file_path,
            file_type=file_type
        )
        session.add(doc)
        session.commit()

        # 索引文档到向量库
        if content:
            from agent import get_kb_tool
            kb_tool = get_kb_tool(knowledge_id)
            kb_tool.index_document(doc.id, title, content)

        return DocumentResponse(
            request_id=str(uuid.uuid4()),
            document_id=doc.id,
            knowledge_id=knowledge_id,
            title=title,
            file_type=file_type,
            response_code=200,
            response_msg="上传并索引成功"
        )
    except Exception as e:
        return DocumentResponse(
            request_id=str(uuid.uuid4()),
            document_id=0,
            knowledge_id=0,
            title="",
            file_type="",
            response_code=500,
            response_msg=f"上传失败: {str(e)}"
        )
    finally:
        session.close()


@app.delete("/document/{document_id}", response_model=DocumentResponse)
def delete_document(document_id: int):
    """删除文档"""
    session = get_session()
    try:
        doc = session.query(Document).filter(Document.id == document_id).first()
        if not doc:
            return DocumentResponse(
                request_id=str(uuid.uuid4()),
                document_id=0,
                knowledge_id=0,
                title="",
                file_type="",
                response_code=404,
                response_msg="文档不存在"
            )

        if doc.file_path and os.path.exists(doc.file_path):
            os.remove(doc.file_path)

        session.delete(doc)
        session.commit()

        return DocumentResponse(
            request_id=str(uuid.uuid4()),
            document_id=document_id,
            knowledge_id=doc.knowledge_id,
            title=doc.title,
            file_type=doc.file_type or "",
            response_code=200,
            response_msg="删除成功"
        )
    finally:
        session.close()


# ============== Agent 问答 ==============

@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    """基于 LangChain Agent 的问答"""
    try:
        agent = get_agent(req.knowledge_id)
        answer = agent.chat(req.message)

        return ChatResponse(
            request_id=str(uuid.uuid4()),
            knowledge_id=req.knowledge_id,
            message=answer,
            response_code=200,
            response_msg="回答成功"
        )
    except Exception as e:
        return ChatResponse(
            request_id=str(uuid.uuid4()),
            knowledge_id=req.knowledge_id,
            message="",
            response_code=500,
            response_msg=f"回答失败: {str(e)}"
        )


@app.get("/health")
def health_check():
    """健康检查"""
    return {"status": "ok", "model": "LangChain Agent"}


if __name__ == "__main__":
    init_db()
    port = config["rag"]["port"]
    uvicorn.run(app, host="0.0.0.0", port=port)