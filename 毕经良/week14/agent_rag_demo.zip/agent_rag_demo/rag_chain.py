"""
RAG 链 - 基于 LangChain 框架实现
"""
import yaml
import os
from typing import List, Dict, Optional

from langchain_core.documents import Document
from langchain_core.vectorstores import VectorStore
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceBgeEmbeddings

from openai import OpenAI

from document_processor import chunk_text

# 加载配置
config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

# 配置读取
LLM_BASE = config["rag"]["llm_base"]
LLM_API_KEY = config["rag"]["llm_api_key"]
LLM_MODEL = config["rag"]["llm_model"]
EMBEDDING_PATH = config["rag"]["embedding_path"]
EMBEDDING_DIMS = config["rag"]["embedding_dims"]
CHUNK_SIZE = config["rag"]["chunk_size"]
CHUNK_OVERLAP = config["rag"]["chunk_overlap"]
TOP_K = config["rag"]["top_k"]

# LangChain 提示词模板
template = """你是一个专家，擅长根据给定的资料回答用户的问题。

参考资料：
{context}

用户问题：{question}

请根据参考资料回答问题。如果资料中没有相关信息，请说明"根据现有资料无法回答这个问题"。
"""

PROMPT = PromptTemplate.from_template(template)


class RAGChain:
    """
    基于 LangChain 框架的 RAG 链

    LangChain 核心组件：
    - Document: 文档对象
    - VectorStore: 向量存储抽象
    - PromptTemplate: 提示词模板
    - ChatOpenAI: LLM 调用
    """

    def __init__(self, knowledge_id: int = 1, persist_directory: str = None):
        self.knowledge_id = knowledge_id

        # 1. 初始化 Embedding 模型 (LangChain 风格)
        self.embeddings = HuggingFaceBgeEmbeddings(
            model_name=EMBEDDING_PATH,
            model_kwargs={"device": "cpu"},
            encode_kwargs={"normalize_embeddings": True}
        )

        # 2. 初始化向量存储 (Chroma + LangChain)
        if persist_directory is None:
            persist_directory = os.path.join(os.path.dirname(__file__), "chroma_db")

        self.vectorstore = Chroma(
            collection_name=f"kb_{knowledge_id}",
            embedding_function=self.embeddings,
            persist_directory=persist_directory
        )

        # 3. 初始化 LLM (LangChain 风格)
        self.llm = OpenAI(
            api_key=LLM_API_KEY,
            base_url=LLM_BASE
        )

        # 4. 构建 RAG Chain
        self._build_chain()

    def _build_chain(self):
        """
        构建 LangChain RAG Chain

        流程: retrieve → format_docs → prompt → llm → output
        """
        def format_docs(docs: List[Document]) -> str:
            """将检索到的文档格式化为字符串"""
            return "\n\n".join([f"[文档 {i+1}]\n{doc.page_content}" for i, doc in enumerate(docs)])

        # LangChain Runnable 风格组装 Chain
        self.chain = (
            {"context": self.vectorstore.as_retriever(search_kwargs={"k": TOP_K}) | format_docs,
             "question": RunnablePassthrough()}
            | PROMPT
            | self.llm
            | StrOutputParser()
        )

    def index_document(self, document_id: int, title: str, content: str, file_path: str = ""):
        """
        将文档内容向量化并存储到向量库

        Args:
            document_id: 文档ID
            title: 文档标题
            content: 文档内容
            file_path: 文件路径
        """
        # 分块
        chunks = chunk_text(content, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP)

        # 创建 LangChain Document 对象
        documents = []
        for i, chunk in enumerate(chunks):
            doc = Document(
                page_content=chunk,
                metadata={
                    "document_id": document_id,
                    "knowledge_id": self.knowledge_id,
                    "title": title,
                    "file_path": file_path,
                    "chunk_index": i
                }
            )
            documents.append(doc)

        # 存储到向量库 (LangChain VectorStore 接口)
        self.vectorstore.add_documents(documents)

    def add_documents(self, documents: List[Document]):
        """添加 LangChain Document 对象到向量库"""
        self.vectorstore.add_documents(documents)

    def retrieve(self, query: str, top_k: int = None) -> List[Document]:
        """检索相关文档"""
        if top_k is None:
            top_k = TOP_K
        return self.vectorstore.similarity_search(query, k=top_k)

    def chat(self, query: str, top_k: int = None) -> str:
        """
        RAG 问答 - 使用 LangChain Chain

        Args:
            query: 用户问题
            top_k: 检索数量

        Returns:
            生成的回答
        """
        if top_k is None:
            top_k = TOP_K

        # 使用 LangChain Chain 进行问答
        return self.chain.invoke(query)


# 全局 RAG 实例缓存
_rag_chains = {}


def get_rag_chain(knowledge_id: int = 1) -> RAGChain:
    """获取指定知识库的 RAG 链"""
    global _rag_chains
    if knowledge_id not in _rag_chains:
        _rag_chains[knowledge_id] = RAGChain(knowledge_id)
    return _rag_chains[knowledge_id]


def clear_rag_chain(knowledge_id: int = None):
    """清空 RAG 链缓存"""
    global _rag_chains
    if knowledge_id is None:
        _rag_chains.clear()
    elif knowledge_id in _rag_chains:
        del _rag_chains[knowledge_id]