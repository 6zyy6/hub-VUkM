"""
向量存储 - 使用 ChromaDB
"""
import chromadb
from chromadb.config import Settings
import os
from typing import List, Dict, Optional
from embeddings import get_embedding_model

# ChromaDB 配置
PERSIST_DIR = os.path.join(os.path.dirname(__file__), "chroma_db")


class VectorStore:
    """向量存储封装"""

    def __init__(self, collection_name: str = "documents"):
        self.embedding_model = get_embedding_model()
        self.client = chromadb.PersistentClient(path=PERSIST_DIR)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"}
        )

    def add_texts(self, texts: List[str], metadatas: List[Dict], ids: List[str] = None):
        """
        添加文本到向量库

        Args:
            texts: 文本列表
            metadatas: 元数据列表
            ids: ID列表
        """
        if ids is None:
            ids = [str(i) for i in range(len(texts))]

        embeddings = self.embedding_model.encode(texts).tolist()

        self.collection.add(
            embeddings=embeddings,
            documents=texts,
            metadatas=metadatas,
            ids=ids
        )

    def search(self, query: str, top_k: int = 5, filter_metadata: Dict = None) -> List[Dict]:
        """
        搜索相似文本

        Args:
            query: 查询文本
            top_k: 返回数量
            filter_metadata: 过滤条件

        Returns:
            搜索结果列表
        """
        query_embedding = self.embedding_model.encode(query).tolist()

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=filter_metadata
        )

        formatted_results = []
        for i in range(len(results["ids"][0])):
            formatted_results.append({
                "id": results["ids"][0][i],
                "text": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i]
            })

        return formatted_results

    def delete(self, ids: List[str] = None, filter_metadata: Dict = None):
        """删除向量"""
        if ids:
            self.collection.delete(ids=ids)
        elif filter_metadata:
            self.collection.delete(where=filter_metadata)

    def clear(self):
        """清空集合"""
        self.client.delete_collection("documents")
        self.collection = self.client.get_or_create_collection(
            name="documents",
            metadata={"hnsw:space": "cosine"}
        )


# 全局向量存储实例
_vector_store = None


def get_vector_store(collection_name: str = "documents") -> VectorStore:
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore(collection_name)
    return _vector_store