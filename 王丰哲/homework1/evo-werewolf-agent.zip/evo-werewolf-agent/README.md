# 多智能体协作与博弈的 Agent Team 实战

## 📋 项目内容总结

该项目的核心目标是**构建一个基于大语言模型（LLM）的、具备高度自主决策与博弈对抗能力的多智能体狼人杀 Team 系统**。

### 1. 核心架构设计

* **多智能体协作/对抗框架（Multi-Agent Framework）**：利用现有的多 Agent 框架（如 LangGraph, AutoGen 或 自研架构）构建玩家生态。每个 Agent 代表一个独立玩家，具备高水平的文本理解与长文本生成能力。
* **信息隔离与认知模型（Information Isolation）**：这是项目的技术难点。系统必须在底座上实现严格的权限控制。例如：
* 狼人知道同伴，但不知道神职。
* 好人对他人身份完全未知。
* 通过**独立记忆体（Memory）**和**私有上下文（Private Context）**，防止 Agent 产生“开天眼”的作弊行为。


* **对局驱动引擎（Game Engine）**：充当“法官/上帝”角色。负责维护全局状态机，驱动黑夜与白天的回合严格流转，下发行动指令，收集 Agent 返回的结构化 JSON/文本决策，并执行胜负判定。
* **全程可观测性日志（Structured Logging）**：系统会实时输出结构化日志，不仅记录“谁死了”、“谁投了谁”，更重要的是捕获 Agent 的**内心独白（Thought/Chain-of-Thought）**、发言草稿以及策略修正过程。

### 2. 前端观战 UI（加分/亮点项）

* 打造一个直观的可视化看板。在纯 AI 对战模式下，用户可以像看综艺一样围观大模型“神仙打架”；同时支持人机混战模式，人类玩家可以通过 UI 与 AI Agent 们同台飙戏、拼演技。

### 3. 进阶方向（三选一）

该课题提供了三个极具深度的自演化和工程化方向：

* **方向 ① 自适应系统（通用 -> 专精）**：Agent 最开始只具备通用的代码/提示词理解能力，通过“读懂自己（评估代码/Prompt） $\rightarrow$ 修改自己 $\rightarrow$ 运行自己”，在没有人工干预的情况下，自我演化出适合狼人杀各角色的专业 Prompt 和反思逻辑。
* **方向 ② 评测、复盘与天梯榜（Leaderboard）**：建立可量化的评价指标（如：发言煽动性、逻辑严密性、挡刀成功率）。在对局结束后，由一个“AI 复盘官”进行归因分析（例如：狼人赢了是因为 3 号聊爆了，还是 4 号悍跳成功）。最终用天梯榜（Leaderboard）展示不同大模型（如 GPT-4o vs Claude 3.5 Sonnet vs DeepSeek）作为 Agent 时的胜率表现。
* **方向 ③ 闭环自进化（RLAIF 思想）**：实现“对局 $\rightarrow$ 数据回流 $\rightarrow$ 归因分析 $\rightarrow$ 策略/Prompt微调 $\rightarrow$ 再对局”的自我强化飞轮，让 Agent 在连续玩了 100 局后，自发学会“倒钩”、“垫飞”、“滴滴代跳”等高阶战术。


## 🚀 FastAPI Server

项目内置了一组 HTTP API，可以远程创建、控制和观察狼人杀对局，方便集成到前端 UI 或自动化测试流水线中。

### 安装依赖

```bash
pip install -r requirements.txt
```

### 配置模型密钥

项目不会在仓库中保存 API Key。运行真实 LLM Agent 前，请先设置环境变量；`.env.example` 提供了示例配置。

PowerShell 示例：

```powershell
$env:OPENAI_BASE_URL="https://dashscope.aliyuncs.com/compatible-mode/v1"
$env:DASHSCOPE_API_KEY="你的 DashScope API Key"
```

### 启动服务器

```bash
uvicorn api.server:app --reload --host 0.0.0.0 --port 8000
```

启动后访问 http://localhost:8000/docs 可查看 Swagger 交互式 API 文档。

### API 端点

| 方法 | 路径 | 功能 |
|------|------|------|
| `GET` | `/` | 服务健康检查 |
| `POST` | `/games` | 创建并初始化一局新游戏 |
| `POST` | `/games/{id}/step` | 推进一个游戏阶段 |
| `GET` | `/games/{id}` | 获取当前游戏完整状态 |
| `GET` | `/games` | 列出所有活跃游戏 |
| `DELETE` | `/games/{id}` | 删除一局游戏 |
| `GET` | `/configs` | 列出可用角色配置 |

### 快速开始

```bash
# 1. 创建一局标准 6 人游戏
curl -X POST http://localhost:8000/games \
  -H 'Content-Type: application/json' \
  -d '{"config_name": "standard_6"}'

# 返回示例：
# {"game_id": "abc12345", "phase": "白天开始", "day_number": 1, "alive_count": 6, "is_game_over": false}

# 2. 获取游戏 ID 后，逐阶段推进
GAME_ID="abc12345"

# 推进一个阶段（返回值中包含当前阶段名、玩家列表、对话、死亡等）
curl -X POST "http://localhost:8000/games/${GAME_ID}/step"

# 3. 查看游戏当前状态
curl -X GET "http://localhost:8000/games/${GAME_ID}"

# 4. 列出所有游戏
curl -X GET "http://localhost:8000/games"

# 5. 查看可用配置
curl -X GET "http://localhost:8000/configs"

# 6. 删除游戏
curl -X DELETE "http://localhost:8000/games/${GAME_ID}"
```

### 游戏阶段说明

每调用一次 `step`，游戏推进一个内部阶段。阶段按以下顺序循环：

| 索引 | 阶段标识 | 说明 |
|------|----------|------|
| 0 | `night_wolf` | 狼人投票选择击杀目标 |
| 1 | `night_seer` | 预言家查验一名玩家 |
| 2 | `night_witch` | 女巫决定是否用药 |
| 3 | `night_result` | 宣布夜晚死亡结果 + 猎人开枪结算 |
| 4 | `day_start` | 白天开始，公布昨晚信息 |
| 5 | `speech` | 所有存活玩家依次发言 |
| 6 | `vote` | 全体投票放逐 |
| 7 | `day_end` | 检查胜负 → 天数 +1 或 游戏结束 |

`step` 响应示例：

```json
{
  "phase": "night_wolf",
  "day_number": 1,
  "step_data": {
    "wolf_votes": [{"player_id": 0, "target": 3}],
    "final_target": 3
  },
  "players": [
    {"player_id": 0, "name": "玩家1", "role": "werewolf", "is_alive": true, ...},
    ...
  ],
  "dialogues": [],
  "deaths": [],
  "is_game_over": false,
  "winner": null
}
```

当 `is_game_over` 为 `true` 时，`winner` 字段会返回胜利方（`"good"` 或 `"evil"`），后续 `step` 调用将始终返回 `game_over` 状态。

### 创建请求参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `config_name` | string | `standard_6` | 角色配置名：`standard_6`、`simple_4`、`big_9` |
| `player_names` | list[string] | null | 自定义玩家名称，不传则自动生成 |
| `shuffle` | bool | true | 是否随机打乱角色分配 |
| `player_styles` | dict | null | 玩家决策风格，`{"0": "bold", "1": "cautious"}` |

可用决策风格：`balanced`（平衡）、`bold`（大胆）、`cautious`（谨慎）、`random`（随机）。

### Vue 前端观战台

项目附带一个 Vue 3 + Vite 前端观战台，提供可视化游戏控制面板。

#### 启动前端

```bash
# 前置条件：后端已在 :8000 运行（见上方启动说明）

# 安装依赖（仅首次）
cd frontend
npm install

# 启动开发服务器
npm run dev
```

启动后浏览器访问 **http://localhost:5173** 即可打开观战台。

如果后端没有运行在默认的 `8000` 端口，可以在启动前端前指定代理目标：

```bash
VITE_API_TARGET=http://127.0.0.1:8001 npm run dev
```

#### 功能

- **创建游戏**：选择配置（标准6人/简易4人/标准9人），可选是否打乱角色
- **自动/手动推进**：点击"自动继续"每 2 秒推进一个阶段，或"暂停"/"单步执行"手动控制
- **玩家面板**：卡片网格展示所有玩家的角色、阵营、存活状态
- **游戏日志**：实时滚动展示各阶段行动（狼人击杀、查验、用药、发言、投票等）
- **胜负揭晓**：游戏结束时弹出胜利方 overlay

前端通过 Vite proxy 将 `/games`、`/configs` 请求代理到后端，无需额外配置 CORS。

---

为了确保游戏在 AI 之间能实现**严格的轮次对等**与**逻辑闭环**，系统将剔除所有非主流的进阶和第三方角色，采用最纯粹的**基础标准板子**：

### 1. 阵营与胜负条件

游戏分为两个互相对立的阵营，采用**屠边规则**：

| 阵营 | 包含身份 | 胜利条件 |
| --- | --- | --- |
| **好人阵营** | 预言家、女巫、猎人、村民 | **消灭所有狼人**。 |
| **狼人阵营** | 基础狼人 | **屠边成功**：即所有【神职】全部死亡，或所有【平民】全部死亡。 |

### 2. 角色行动空间（技能限制）

每个 Agent 必须在被法官叫醒时，在其特定的“行动空间”内做出合法决策：

* **狼人 (Werewolf)**：
* **黑夜**：狼人集体睁眼，通过内部私密通道（密聊机制）达成共识，共同输出一个目标编号进行“刀人”。
* **白天**：可以正常发言伪装，或在投票前选择**自爆**（翻牌出局，强行终止白天，直接天黑）。


* **预言家 (Seer) 【神职】**：
* **黑夜**：每晚查验一名存活玩家。法官仅返回 `好人` 或 `狼人` 的二元结果，不透露具体职业。


* **女巫 (Witch) 【神职】**：
* **黑夜**：拥有一瓶**解药**（得知今晚死者并选择是否复活）和一瓶**毒药**（任意毒死一名玩家）。每瓶药一局限用一次，单夜不能双药同用，**且全程不可自救**。


* **猎人 (Hunter) 【神职】**：
* **被动**：因夜间被刀或白天被投票放逐而死时，可翻牌开枪带走一人。若被女巫**毒死**，则技能锁定，无法开枪（闷枪）。


* **村民 (Villager) 【平民】**：
* **无夜间技能**：黑夜全程闭眼，白天纯靠听取发言进行逻辑推理与放逐投票。



### 3. 基础游戏标准流转流程

系统引擎（法官）将通过以下严格的状态机驱动游戏：

```
天黑闭眼 ──► 狼人密聊刀人 ──► 预言家验人 ──► 女巫用药判定 ──► 天亮了
                                                                 │
                                                                 ▼
公放逐投 ◄── 自由发言辩论 ◄── 竞选警长(上警) ◄── 法官宣布死讯 ◄── 结算夜间伤亡

```

1. **警长竞选（首日白天）**：玩家可选择“上警”争夺警徽。参选玩家轮流发言，由未参选（警下）的 Agent 投票选出警长。警长拥有 **1.5 票**投票权并可决定发言顺序。
2. **白天发言与公投**：法官宣布死讯（死者留遗言） $\rightarrow$ 幸存 Agent 依次进行文本发言（大模型需完成：**表水**自证、**踩**他人漏洞、或**悍跳**伪装） $\rightarrow$ 所有人公开投票放逐一名嫌疑人（得票最高者出局并留遗言）。
3. **循环直至终局**：重复黑夜与白天，直到触发引擎的胜负判定条件，宣告游戏结束。
