"""main_demo 演示入口测试"""

from main_demo import normalize_player_styles


def test_normalize_player_styles_matches_player_count():
    styles = normalize_player_styles(4)

    assert set(styles.keys()) == {0, 1, 2, 3}
    assert styles[0] == "bold"
    assert styles[3] == "cautious"


def test_normalize_player_styles_filters_extra_players():
    styles = normalize_player_styles(4, {0: "random", 5: "bold"})

    assert styles[0] == "random"
    assert 5 not in styles
    assert set(styles.keys()) == {0, 1, 2, 3}
