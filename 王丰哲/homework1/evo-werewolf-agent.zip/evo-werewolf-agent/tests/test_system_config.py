import json
from pathlib import Path

from schema.system_config import load_system_config


config = load_system_config("config/system_config.json")


def test_repository_config_does_not_ship_api_key():
    config_path = Path("config/system_config.json")
    raw_config = json.loads(config_path.read_text(encoding="utf-8"))

    assert raw_config["api_key"] == ""
